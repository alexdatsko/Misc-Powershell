﻿
# Add Security GPO's - Windows Server 2012 R2 and later

# Path to directory where backed up GPO's are stored. Default = Current location
$GPOPath = "$(Get-Location)\"
# Words to ignore... can be lower case, compared in 
$ignorelist = ("enable disable yes no set the last fix retry retries setting settings account guest administrator admin dc dns dhcp windows 7 8 8.1 10 2012 r2 2016 2019 office 2011 2013 explorer rce cve information disclosure vulnerability vuln - .").ToUpper()
# Global var of matched words when comparing strings
$matchedwords = ""

function Compare-Strings {

    param (
        $string1,
        $string2
    )

  $result = $false
  if ($string2.Length -gt 1) { # If comparing GPO has no name, do not compare..
    #Write-Host "String1:  [$string1] Length in words: [$($string1.split(' ').length)] Split: $($string1.split(' '))"
    #Write-Host "String2:  [$string2] Length in words: [$($string2.split(' ').length)] Split: $($string2.split(' '))"

    for ($j = 0; $j -le ($string2.split(' ').Count); $j++) {     # iterate through existing gpo name 
      for ($i = 0; $i -le ($string1.split(' ').Count); $i++) {   # iterate through import gpo name..
        #  current word number is $i , current word is  $string1.split(' ')[$i]
        $current = ($string1.split(' ')[$i])
        $existing = ($string2.split(' ')[$j])
        if (($current.length -gt 1) -and ($existing.length -gt 1)) {
          $current = $current.ToUpper()
          $existing = $existing.ToUpper()
          #Write-Host " Ignorelist: $Ignorelist `r`n Current: $Current"
          if ($ignorelist -like "*$($current)*") {
            #Write-Host "Ignoring word $current"
          } else {
            if ($existing -like "*$($current)*") {   
              # don't match 0 or 1 length words
              # even if the word exists inside another word in the existing GPO.. return true
             $matchedwords += $current
             $result = $true
              #Write-Host "Hit: $current -like *$($existing)*"
            }
          } 
        }
      }
    }
  }
  return $false
}

function Create-SecurityGPO {
  param(
     [string] $GUID,
     [string] $TargetName)

  Write-Host "`r`n`r`n---------------------------------`r`n[.] Processing : $GUID - $TargetName"
  $DomainString = ""
  if ($TargetName -like "*DC -*") {
    Write-Host "Detected Domain controller GPO, adding OU=DomainControllers, to LDAP string"
    $DomainString = "OU=Domain Controllers,"+(Get-ADDomain | Select -expandproperty DistinguishedName)
  } else {
    $DomainString = (Get-ADDomain | Select -expandproperty DistinguishedName)
  }

  $GUIDFolder="{$($GUID)}"
  if (test-path($GUIDFolder)) { # Folder found, we are in correct directory
    #Write-Host "[o] $GUIDFolder Folder found."
  } else { # GUID Folder not found
    Write-Host "`r`nERROR: Please run this in the BackupsGPOs folder where $GUID can be found!`r`n"
    Write-Error "Exiting - $GUID - folder not found."
    exit
  }
  
  $GPO = Import-GPO -BackupId $GUID -TargetName $TargetName -path $GPOPath -CreateIfNeeded # -WhatIf 
  # ^^^ Tried to grab the info here instead of importing, but I think I will have to just remove it later if they don't want it imported, this is broken currently
  
  $ExistingGPOList = (Get-GPO -All)
  
  # Lets get a 
  Get-GPOReport -Guid $guid -ReportType 'HTML' -Path 'C:\Temp\AppL-Report.html'
  
  
  # Check by name
  $poss = 1
  $skipchecking = $false
  foreach ($ExistingGPO in $ExistingGPOList) {
    if ((Compare-Strings ($ExistingGPO.DisplayName) ($GPO.DisplayName)) -and !($skipchecking -eq $true)) { 
      Write-Host "Possible duplicate $poss. NEW GPO: " -ForegroundColor Red -NoNewLine
      Write-Host "[$($GPO.DisplayName)]" -ForegroundColor Gray -NoNewLine
      Write-Host " EXISTING GPO: " -ForegroundColor Red -NoNewLine
      Write-Host "[$($ExistingGPO.DisplayName)]" -ForegroundColor Gray
      $yesno = (Read-Host "This GPO might already be loaded.  Skip [$($GPO.DisplayName)]? [Y,n,s=skip checking] ").toUpper()
      if ($yesno -eq "S") { $skipchecking = $true ; Write-Host "Skipping All!!" }
      if (($yesno -eq "Y") -or ($yesno -eq "")) {
        Write-Host "Skipping!"
        Return
      }
      $poss += 1 
    }
  }
  #Write-Debug "Loaded $TargetName [$GUID]"
  

  $yesno = (Read-Host "Apply $TargetName to domain $($DomainString)? [Y] ").toUpper()
  if (($yesno -eq "Y") -or ($yesno -eq "")) {
    #Write-Host "Using $DomainString "
    $GPO | New-GPLink -Target $DomainString -LinkEnabled Yes
    Write-Host "Linked $GUID to $DomainString" 
  } else { 
    
    try { # Have user pick from a list of OU's
      $OUList = (Get-ADOrganizationalUnit -filter *)
      Write-Host "List of OUs:"
      $i = 0
      foreach ($OU in $OUList) {
        Write-Host "$i : [$($OU.Name)] - $($OU.DistinguishedName)"
        $i += 1
      }
      $maxopt = $i
      Write-Host "$maxopt : DO NOT IMPORT THIS GPO"
      $input = Read-Host "Please pick the OU to apply to [$maxopt] "
      $choice = [int]$input
      if ($input -eq "") { $choice = [int]$i }  #If no input, do nothing.
      #Write-Host "Input : $input `r`nChoice : $choice" 
      if (!($choice -eq $maxopt) -and !($choice -eq "")) {  # make sure we have picked something, ignore if its DO NOT IMPORT or somehow blank string
        $DomainOUName = $OUList[$choice].Name
        $DomainString = $OUList[$choice].DistinguishedName
        Write-Host "You have picked: $DomainOUName - $DomainString"
      } else {
        Write-Host "[!] WILL NOT IMPORT THIS POLICY."
        Return
      }
    } catch { 
      Write-Error "`r`n(Get-ADOrganizationalUnit -filter *) error listing domains!`r`n"
      Exit
    } 
    $choices = @()
    for ($j=0 ; $j -le $maxopt ; $j++) { $choices += [int]$j }  #Ugly.. Further validation that choice is an actual choice..
    #Write-Host "Choice : $choice `r`nChoices : $choices`r`nChoices contains choice : $($choices.Contains($choice))"
    if ($choices.Contains($choice)) {
      $yesno = (Read-Host "Link: Apply ( $TargetName ) to OU $DomainOUName [ $($DomainString) ]? [Y] ").toUpper()
      if (($yesno -eq "Y") -or ($yesno -eq "")) {
        Write-Host "Using $DomainString "
      } else {
        $IncorrectOU = 0
        while ($IncorrectOU) {
          $DomainString = Read-Host "Please type domain LDAP path to use instead of $($DomainString)?  "
          if ([adsi]::Exists("LDAP://$($DomainString)")) { $IncorrectOU = 1 } else { Write-Host "LDAP://$($DomainString) not found!! Try again.." }
        }
      }
      try {
        $GPO = Import-GPO -BackupId $GUID -TargetName $TargetName -path $GPOPath -CreateIfNeeded  #Already imported above..
        Write-Host "Imported policy: $TargetName [$GUID]"
      } catch {
        Write-Host "Error: could not import $($GPO.DisplayName) .. Exiting!"
        exit
      }
      try { 
        Write-Host "Trying to Link : ( $TargetName ) to $DomainOUName [ $DomainString ]" 
        $GPO | New-GPLink -Target $DomainString -LinkEnabled Yes
      } catch {
        Write-Host "Error: could not link $GPO to $DomainString .. Passing"
        #exit
      }
    }
  }


}

function Replicate-AD {
  $yesno = (Read-Host "Run repadmin /syncall /APeD to replicate to all DCs? [Y] ").toUpper()
  if (($yesno -eq "Y") -or ($yesno -eq "")) {
    Write-Host "Running Repadmin:"
    $output = repadmin /syncall /APeD
    $yesno = (Read-Host "Display output? [Y] ").toUpper()
    if (($yesno -eq "Y") -or ($yesno -eq "")) {
      $output
    }
  } 
}

Write-Host "Checking Domain functional level..."
$Domain = Get-ADDomain | Select -expandproperty DistinguishedName
$Func = (get-ADDomain | select -ExpandProperty DomainMode)
$FunctionalLevelMatch =  $func -match "\d+"
$FunctionalLevel = $matches[0]
If ($FunctionalLevel -lt 2012) {
  # It seems like these are all okay on 2008 r2 functional level, so far..
  #Write-Host "[X] Error!!  The functional level is $func .. Should be 2012 R2 or higher.. Exiting"
  #exit
} else {
  Write-Host "[o] Domain Functional level $func is >= 2012 R2 .. Good."
}

Create-SecurityGPO 3386378B-22FD-4028-8EF6-D2595ADA8F7E "Log4J Mitigation"
Create-SecurityGPO 3BE5A652-3183-4EAA-80A2-3A830418D958 "WinRM - Enable"

Replicate-AD
