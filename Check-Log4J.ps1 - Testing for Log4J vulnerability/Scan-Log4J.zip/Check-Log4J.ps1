﻿Start-Transcript

Write-Host "[ ] Grabbing list of computers with Get-ADComputer .."
$Computers = (Get-ADComputer -Filter {(OperatingSystem -like "*windows*") -and (Enabled -eq "True")}).Name

Foreach ($Computer in $Computers) {
  #if (Test-Connection $Computer) {   # No need for 2nd error, this should be caught first
    Invoke-Command -Computer $Computer -ScriptBlock {
    
        $Paths = @(        # Search both C: and D:
          'C:\', 'D:\'
        )

        $Computer = hostname
        Write-Host "-----------------------------------------------------`r`n---- $($Computer) ----" -ForegroundColor White
    
        Write-Host "[ ] Searching for Apache/Tomcat installations .." -ForegroundColor Gray
        $Services = Get-Service | ?{ (($_.Name -like "*apache*") -or ($_.Name -like "*tomcat*")) } 
        if ($Services) { Write-Host "$Services" } else { Write-Host "[X]   No apache or tomcat services found" -ForegroundColor Green }
    
        $ApacheService = Get-WmiObject win32_service | ?{ $_.Name -like "*apache*" } | select Name, DisplayName, State, PathName
        $TomcatService = Get-WmiObject win32_service | ?{ $_.Name -like "*tomcat*" } | select Name, DisplayName, State, PathName
        if ($ApacheService) { Write-Host "[!] Apache Service found: $ApacheService " -ForegroundColor Red } 
        if ($TomcatService) { Write-Host "[!] Tomcat Service found: $TomcatService " -ForegroundColor Red } 
    
        if (!(Test-Path("C:\Temp"))) {
          New-Item -ItemType Directory "C:\Temp"
        } 
        set-Location "C:\Temp"
        <#
        if (!(Test-Path("C:\Temp\Log4j2-scan.exe"))) { 
            Write-Host "[ ] Grabbing log4j2-scan from  https://github.com/logpresso/CVE-2021-44228-Scanner/releases/download/v1.2.3/logpresso-log4j2-scan-1.2.3-win64.7z .."
            $zipfilePath = "C:\Temp\log4j2-scan.7z"
            $destinationUnzipPath = "C:\Temp"
            [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
            wget "https://github.com/logpresso/CVE-2021-44228-Scanner/releases/download/v1.2.3/logpresso-log4j2-scan-1.2.3-win64.7z" -OutFile $zipfilePath
            Write-Host "[ ] Extracting w/ 7zip .."
            try { 
              & ${env:ProgramFiles}\7-Zip\7z.exe x $zipfilePath "-o$($destinationUnzipPath)" -y | Out-Null 
            } catch { 
              Write-Error "[X] Couldn't extract using 7z.exe!  Exiting.."
              exit
            }
        } #>
        Copy-Item "\\spr-server\data\MME\log4j2-scan.exe" "c:\temp" -Force
        Copy-Item "\\spr-server\data\MME\vcruntime140.dll" "c:\temp" -Force


        foreach ($Path in $Paths) {
            # Search with Log4J2-scan.exe
            Write-Host "[ ] Searching $Path with Log4J2-Scan.exe.." -ForegroundColor Gray
            $Output = C:\Temp\log4j2-scan.exe --force-fix $Path  
            if ($Output) { 
                Write-Host "[o] Log4J2-Scan.exe $Path output:  " 
                ForEach ($line in $Output) {
                  Write-host "[o]   $line"
                }
            } else { 
                Write-Host "[X]   Log4J2-Scan.exe - no output" -ForegroundColor Green 
            }
        
            # Search manually
            #Write-Host "[ ] Searching $Path for possibly vulnerable installations .." -ForegroundColor Gray
            #$JndiFound = (gci $Path -rec -force -include *.jar -ea 0 | foreach {select-string "JndiLookup.class" $_} | select -exp Path)
            #if ($JndiFound) { 
            #    foreach ($Jndi in $JndiFound) { 
            #        Write-Host "[!] Possible exploitable installation found: $Jndi " -ForegroundColor Red 
            #    }
            #} else { Write-Host "[X]   No exploitable installations found" -ForegroundColor Green }
        }
    
        Write-Host "[o] Setting Environment variable mitigation just in case.."
        set LOG4J_FORMAT_MSG_NO_LOOKUPS=true
        $env:LOG4J_FORMAT_MSG_NO_LOOKUPS = "true"

    }
  } else {
    Write-Host "[x] $Computer not reachable.." -ForegroundColor Red
 # }
}

Stop-Transcript
