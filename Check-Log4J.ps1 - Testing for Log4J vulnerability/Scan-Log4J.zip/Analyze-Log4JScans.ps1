﻿$serverpath = "\\spr-server\sysvol\AboutFacesAndBraces.local\scripts\results"

$Filenames = (gci $serverpath).Name
foreach ($file in $filenames) {
  $in = Get-Content $serverpath\$file
  $output = $in | Select-String -Pattern "vulnerable files" 
  Write-Output "`r`n---------------------------------------- $file "
  foreach ($out in $output) {
    Write-Output "$out"
  }
}