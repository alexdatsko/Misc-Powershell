#!/bin/bash

#find / | grep -F '.jar'

echo "Searching for Log4J installations:"
find / -name 'log4j*'

echo "Setting LOG4J_FORMAT_MSG_NO_LOOKUPS=true mitigation:"
export LOG4J_FORMAT_MSG_NO_LOOKUPS=true

echo "Searching for exploitation attempts in uncompressed files in folder /var/log and all subfolders:"
sudo egrep -I -i -r '\$({|%7B)jndi:(ldap[s]?|rmi|dns):/[^\n]+' /var/log

echo "Searching for exploitation attempts in compressed files in folder /var/log and all subfolders:"
sudo find /var/log -name *.gz -print0 | xargs -0 zgrep -E -i '\$({|%7B)jndi:(ldap[s]?|rmi|dns):[^\n]+'

echo "Searching for obfuscated variants (Lacks the file name in a search!!):"
sudo find /var/log/ -type f -exec sh -c "cat {} | sed -e 's/\${lower://'g | tr -d '}' | egrep -I -i 'jndi:(ldap[s]?|rmi|dns):'" \;

echo "Searching for obfuscated variants in compressed files in folder /var/log and all subfolders:"
sudo find /var/log/ -name "*.log.gz" -type f -exec sh -c "zcat {} | sed -e 's/\${lower://'g | tr -d '}' | egrep -i 'jndi:(ldap[s]?|rmi|dns):'" \;
