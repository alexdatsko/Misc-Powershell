﻿Start-Transcript

$Paths = @(
  'C:\', 'D:\'
)

Function IfExist-Service {
  param ($ServiceN)

  $Service = Get-Service -Name $ServiceN -ErrorAction SilentlyContinue
  if ($Service) {
    return $true
  } else {
    return $false
  }
}

Function IfExist-StopService {
  param ($ServiceName)
  
  $Service = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue

  if ($Service.Length -gt 0) {
    try { 
      Get-Service -Name $ServiceName | Stop-Service -ErrorAction SilentlyContinue
      Write-Host "[o] Stopped service $Servicename "
    } catch {
      Write-Host "[x] Couldn't stop service $Servicename ! Is this user an Administrator?" -ForegroundColor Red
    }
  } else {
    "Service $ServiceName doesn't exist!"
  }
}

Function IfExist-StartService {
  param ($ServiceName)
  
  $Service = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
  if ($Service.Length -gt 0) {
    try { 
      Get-Service -Name $ServiceName | Start-Service -ErrorAction SilentlyContinue
      Write-Host "[o] Started service $Servicename "
    } catch {
      Write-Host "[x] Couldn't start service $Servicename ! Is this user an Administrator?" -ForegroundColor Red
    }
  } else {
    "Service $ServiceName doesn't exist!"
  }
}

Write-Host "`r`n[ ] Don't forget to stop any services that need to be fixed!" -ForegroundColor Red

Write-Host "`r`n[x] Stopping APCPBEAgent, helper, Wagsrvc, (and any other services).." -ForegroundColor White
IfExist-StopService apcpbeagent
IfExist-StopService helper
if (IfExist-Service wagsrvc) {
  IfExist-StopService wagsrvc
  if (test-path "C:\Program Files (x86)\WatchGuard\Active Directory Helper\helper.war") {
    Write-Host "[ ] Renaming C:\Program Files (x86)\WatchGuard\Active Directory Helper\helper.war to helper2.war as sometimes the fix doesn't work properly unless its renamed..."
    ren "C:\Program Files (x86)\WatchGuard\Active Directory Helper\helper.war" "C:\Program Files (x86)\WatchGuard\Active Directory Helper\helper2.war"
  }
}

foreach ($Path in $Paths) {
    # Search with Lof4J2-scan.exe
    Write-Host "[ ] Searching $Path with Log4J2-Scan.exe --force-fix $Path .." -ForegroundColor Gray
    $Output = C:\Temp\log4j2-scan.exe --force-fix $Path
    if ($Output) { 
      Write-Host "[o] Log4J2-Scan.exe $Path output:  " 
      $Output | ForEach-Object { Write-Host "$_" }
    } else { 
      Write-Host "[X]   Log4J2-Scan.exe - no output" -ForegroundColor Green 
    }
        
}
    
Write-Host "[o] Setting Environment variable temporary mitigation as well.."
set LOG4J_FORMAT_MSG_NO_LOOKUPS=true
$env:LOG4J_FORMAT_MSG_NO_LOOKUPS = "true"

if (IfExist-Service wagsrvc) {
  if (test-path "C:\Program Files (x86)\WatchGuard\Active Directory Helper\helper2.war") {
    Write-Host "[ ] Renaming C:\Program Files (x86)\WatchGuard\Active Directory Helper\helper2.war to helper.war ..."
    ren "C:\Program Files (x86)\WatchGuard\Active Directory Helper\helper2.war" "C:\Program Files (x86)\WatchGuard\Active Directory Helper\helper.war"
  }
}
Write-Host "`r`n[o] Starting APCPBEAgent, helper, Wagsrvc, (and any other services).." -ForegroundColor White
IfExist-StartService apcpbeagent
IfExist-StartService helper
IfExist-StartService wagsrvc

if (ifExist-Service apcpbeagent) {
  Write-Host "`r`n[o] Starting Chrome, please login to the APC Powerchute software for testing.." -ForegroundColor White
  . "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe" "https://localhost:6547/"
}

Stop-Transcript
