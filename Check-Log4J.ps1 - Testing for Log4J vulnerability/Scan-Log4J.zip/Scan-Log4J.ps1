$path = "\\spr-server\sysvol\AboutFacesAndBraces.local\scripts"
$hostname = hostname
$datetime = get-Date -format "yyyy-MM-dd hh:mm"

if (test-path $path) {
  if (!(test-path "$path\results")) {
    New-Item -ItemType Directory "$path\results"
  }
} else { Write-Error "Can't find $path " ; Exit} 

if (!(test-path c:\temp)) {
  New-Item -ItemType Directory "c:\Temp"
}

"----------------------------------------------------`r`nStarting scan on $hostname - $datetime`r`n----------------------------------------------------" | out-file "$path\results\$hostname.txt" -append

copy-item "$path\log4j2-scan.exe" c:\temp
copy-item "$path\vcruntime140.dll" c:\temp

Set-Location c:\temp
. c:\temp\log4j2-scan.exe c:\ | out-file "$path\results\$hostname.txt" -append
if (test-path -path d:\) {
  . c:\temp\log4j2-scan.exe d:\ | out-file "$path\results\$hostname.txt" -append
}

get-content "$path\results\$hostname.txt"