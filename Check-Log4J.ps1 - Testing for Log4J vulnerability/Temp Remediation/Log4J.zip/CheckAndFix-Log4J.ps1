﻿Start-Transcript

$Log4JPath = "C:\Temp\Log4J"

if (!(Test-Path("C:\Temp"))) {
    Write-Host "[ ] Creating folder C:\Temp .. "
    New-Item -ItemType Directory "C:\Temp"
} 
        
if (!(Test-Path($Log4JPath))) {
    Write-Host "[ ] Creating folder $Log4JPath .. "
    New-Item -ItemType Directory $Log4JPath
} 


# Create new share 'Temp' with Everyone read access.
$servershare = "\\$($env:computername)\Temp"
Write-Host "[ ] Creating new temp share $servershare .."
$Share = New-SmbShare -Name "Temp" -Path "C:\Temp" -EncryptData $True -CachingMode None 
Grant-SmbShareAccess -Name "Temp" -AccountName "Everyone" -AccessRight Read -Force

# Make sure the folder security is set to Read/Execute for Everyone
$cmd = 'icacls "'+$Log4JPath+'" /grant:r Everyone:(RX)'
cmd.exe /c $cmd
Copy-Item "log4j2-scan.exe" "$Log4JPath" -Force

########################## Start scan

Write-Host "[ ] Grabbing list of computers with Get-ADComputer .."
$Computers = (Get-ADComputer -Filter {(OperatingSystem -like "*windows*") -and (Enabled -eq "True")}).Name

#Foreach ($Computer in $Computers) {   
# Execute in parallel rather than serial, much quicker!!
Invoke-Command -Computer $Computers -ScriptBlock {
    
    $Log4JPath = $using:Log4JPath

    $Paths = @(        # Search both C: and D:
        'C:\', 'D:\'
    )

    $Computer = hostname
    Write-Host "-----------------------------------------------------`r`n---- $($Computer) ----" -ForegroundColor White
    
    Write-Host "[ ] Searching for Apache/Tomcat installations .." -ForegroundColor Gray
    $Services = Get-Service | ?{ (($_.Name -like "*apache*") -or ($_.Name -like "*tomcat*")) } 
    if ($Services) { Write-Host "$Services" } else { Write-Host "[X]   No apache or tomcat services found" -ForegroundColor Green }
    
    $ApacheService = Get-WmiObject win32_service | ?{ $_.Name -like "*apache*" } | select Name, DisplayName, State, PathName
    $TomcatService = Get-WmiObject win32_service | ?{ $_.Name -like "*tomcat*" } | select Name, DisplayName, State, PathName
    if ($ApacheService) { Write-Host "[!] Apache Service found: $ApacheService " -ForegroundColor Red } 
    if ($TomcatService) { Write-Host "[!] Tomcat Service found: $TomcatService " -ForegroundColor Red } 
    
    if (!(Test-Path("C:\Temp"))) {
        Write-Host "[ ] Creating folder C:\Temp .. "
        New-Item -ItemType Directory "C:\Temp"
    } 
        
    if (!(Test-Path($Log4JPath))) {
        Write-Host "[ ] Creating folder $Log4JPath .. "
        New-Item -ItemType Directory $Log4JPath
    } 
    set-Location $Log4JPath

    if (!(Test-Path("$($Log4JPath)\Log4j2-scan.exe"))) { 
        # Not bothering to download this .. Let's copy it from the share
        #Write-Host "[ ] Grabbing log4j2-scan from  https://github.com/logpresso/CVE-2021-44228-Scanner/releases/download/v1.2.3/logpresso-log4j2-scan-1.2.3-win64.7z .."
        #$zipfilePath = "$($Log4JPath)\log4j2-scan.7z"
        #$destinationUnzipPath = $($Log4JPath)
        #[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        #wget "https://github.com/logpresso/CVE-2021-44228-Scanner/releases/download/v1.2.3/logpresso-log4j2-scan-1.2.3-win64.7z" -OutFile $zipfilePath
            
        Write-Host "[ ] Copying log4j2-scan.exe from share $($using:servershare) .."
        Copy-Item "$($using:servershare)\log4j2\log4j2-scan.exe" $Log4JPath -Force
        
        #Copy-Item $servershare\7z.exe $Log4JPath -Force
        #Copy-Item $servershare\7z.dll $Log4JPath -Force

        #Write-Host "[ ] Extracting w/ 7zip .."
        #try { 
        #  & $($Log4JPath)\7z.exe x $zipfilePath "-o$($destinationUnzipPath)" -y | Out-Null 
        #} catch { 
        #  Write-Error "[X] Couldn't extract using 7z.exe!  Exiting.."
        #  exit
        #}
    }

    foreach ($Path in $Paths) {
        # Search with Log4J2-scan.exe
        Write-Host "[ ] Searching $Path with Log4J2-Scan.exe, using --force-fix .." -ForegroundColor Gray
        $Output = .\log4j2-scan.exe --force-fix $Path  
        if ($Output) { Write-Host "[o] Log4J2-Scan.exe $Path output:  `r`n$Output" } else { Write-Host "[X]   Log4J2-Scan.exe - no output" -ForegroundColor Green }
        
        # Search manually
        #Write-Host "[ ] Searching $Path for possibly vulnerable installations .." -ForegroundColor Gray
        #$JndiFound = (gci $Path -rec -force -include *.jar -ea 0 | foreach {select-string "JndiLookup.class" $_} | select -exp Path)
        #if ($JndiFound) { 
        #    foreach ($Jndi in $JndiFound) { 
        #        Write-Host "[!] Possible exploitable installation found: $Jndi " -ForegroundColor Red 
        #    }
        #} else { Write-Host "[X]   No exploitable installations found" -ForegroundColor Green }
    }
    
    Write-Host "[o] Setting Environment variable mitigation just in case.."
    set LOG4J_FORMAT_MSG_NO_LOOKUPS=true
    $env:LOG4J_FORMAT_MSG_NO_LOOKUPS = "true"
}

Write-Host "[x] Removing temp File share .."
$Share | Remove-FileShare

Stop-Transcript