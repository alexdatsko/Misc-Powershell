#########################################
# Install-SecurityFixes.ps1
# Alex Datsko - alex.datsko@mmeconsulting.com

[cmdletbinding()]  # For verbose, debug etc
param (
  [switch] $Automated = $false   # this allows us to run without supervision and apply all changes (could be dangerous!)
)
#Clear

$oldPwd = $pwd                               # Grab location script was run from
$ConfigFile = "$oldpwd\_config.ps1"          # Configuration file 
$QIDsListFile = "$oldpwd\QIDLists.ps1"       # QID List file 
$OSVersion = ([environment]::OSVersion.Version).Major
$QIDsAdded = @()

$tmp = "$($env:temp)\SecAud"                 # "temp" Temporary folder to save downloaded files to, this will be overwritten when checking config ..
#Start a transscript of what happens while the script is running
if (!(Test-Path $tmp)) { New-Item -ItemType Directory $tmp }
$dateshort= Get-Date -Format "yyyy-MM-dd"
try {
  Start-Transcript "$($tmp)\Install-SecurityFixes_$($dateshort).log" -Force -ErrorAction SilentlyContinue
} catch {
  if ($Error[0].Exception.Message -match 'Transcript is already in progress') {
    Write-Warning '[!] Start-Transcript: Already running.'
  } else {
    # re-throw the error if it's not the expected error
    throw $_
  }
}

# ----------- Script specific vars:  ---------------

# No comments after the version number on the next line- Will screw up updates!
$Version = "0.35.38"
     # New in this version: MS Store open on vuln find, only offer this once..
$VersionInfo = "v$($Version) - Last modified: 5/09/23"

# Self-elevate the script if required
if (-Not ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] 'Administrator')) {
    Write-Output "`n[!] Not running under Admin context - Re-launching as admin!"
    if ([int](Get-CimInstance -Class Win32_OperatingSystem | Select-Object -ExpandProperty BuildNumber) -ge 6000) {
        $Command = "-File `"" + $MyInvocation.MyCommand.Path + "`" " + $MyInvocation.UnboundArguments
        Start-Process -FilePath PowerShell.exe -Verb RunAs -ArgumentList $Command
        sl $pwd
        Exit
 }
}

# Change title of window
$host.ui.RawUI.WindowTitle = "$($env:COMPUTERNAME) - Install-SecurityFixes.ps1"

# Try to use TLS 1.2, this fixes many SSL problems with downloading files, before TLS 1.2 is not secure any longer.
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

if ($Automated) {
  Write-Host "`n[!] Running in automated mode!`n"   -ForegroundColor Red
}

function Get-YesNo {
  param ([string] $text,
         [string] $results)
  
  $done = 0
  if (!($Automated)) { 
    while ($done -eq 0) {
      $yesno = Read-Host  "`n[?] $text [n] "
      if ($yesno.ToUpper()[0] -eq 'Y') { return $true } 
      if ($yesno.ToUpper()[0] -eq 'N' -or $yesno -eq '') { return $false } 
      if ($yesno.ToUpper()[0] -eq 'S') { 
          Write-Host "[i] Results: " -ForegroundColor Yellow
          foreach ($result in $Results) {
            Write-Host "$($result)" -ForegroundColor Yellow
          }
       }
    }
  } else {  # Automated mode. Show results for -Verbose, then apply fix
    Write-Verbose "[i] Results: "
    foreach ($result in $Results) {
      Write-Verbose "$($result)"
    }
    Write-Host "[+] Applying fix for $text .."
    return $true
  }
}

# skip to # MAIN # 

################################################# SCRIPT FUNCTIONS ###############################################

function Read-QIDLists {    # NOT USING, THIS IS NOT 
  # READ IN VALUES FROM QIDsList 
  if ($QIDsListFile -like "*.ps1") {
    if (Test-Path $QIDsListFile) {
      try {
        #. "$($QIDsListFile)"  # This does not import our variables for global use..
        $scriptContent = Get-Content $QIDsListFile -Raw
        $scriptBlock = [scriptblock]::Create($scriptContent)
    
        # Invoke the script block in the global scope
        &$scriptBlock
        foreach ($variableName in $scriptBlock.Variables.Keys) {
            # Define each variable in the global scope
            #$global:$variableName = $scriptBlock.Variables[$variableName]  # Need to do this for all other vars, not ideal.. skipping this for now.
        }
      } catch {
        Write-Output "`n`n[!] ERROR: Couldn't import $($QIDsListFile) !! Exiting"
        Stop-Transcript
        sl $pwd
        Exit
      }
    } else {
      Write-Output "`n`n[!] Warning: Couldn't find $($QIDsListFile) .. Will try to update.."
    }
    # Update will be done separately..
  }
}

function Get-OSVersion {
  return (Get-CimInstance Win32_OperatingSystem).version
}

function Check-NewerScriptVersion {   # Check in ps1 file for VersionStr and report back if its newer than the current value ($VersionToCheck), returns version# if so.
  param ([string]$Filename,
         [string]$VersionStr,
         [string]$VersionToCheck)
  
  $OSVersionMaj = Get-OSVersion
  $FileContents = Get-Content $Filename
  $TotalLines = $FileContents.Length
  Write-Verbose "[.] Loaded $TotalLines lines from $($Filename) .. Checking for $($VersionStr)"
  foreach ($line in $FileContents) {
    if ($line -like "$VersionStr") {
      if ($line -like '#') {  # Handle comment on same line, i.e: $Version = "1.2.3.0" # Comment ..
        $VersionFound = $line.split('=')[1].split("#")[0].trim().replace('"','')
      } else {
        $VersionFound = $line.split('=')[1].trim().replace('"','')
      }
      Write-Verbose " New script version: $([version]$VersionFound)"
      #if ($OSVersionMaj -ge 10) { Write-Verbose " New script version Hex: $($VersionFound | Format-Hex)" }
      Write-Verbose " Current version: $([version]$VersionToCheck) "
      #if ($OSVersionMaj -ge 10) { Write-Verbose " Current version hex: $($VersionToCheck | Format-Hex)" }
      if ([version]$VersionFound -gt [version]$VersionToCheck) {
        Write-Verbose "[+] Version found $($VersionFound) is newer than $($VersionToCheck)"
        return $VersionFound;
      }
      if ([version]$VersionFound -eq [version]$VersionToCheck) {
        Write-Verbose "[=] Version found is the same: $([version]$VersionFound)"
        return $false;
      }
      if ([version]$VersionFound -lt [version]$VersionToCheck) {
        Write-Verbose "[-] Version found $($VersionFound) is older than $($VersionToCheck)"
        return $false;
      }
    }
  }
  Write-Output "[.] ERROR: Script version not found in version from Github!?! Not good, github or internet issue?"
  return $false;
}

function Update-File {  # Not even used currently, but maybe eventually?
  param ([string]$url,
        [string]$FilenameTmp,
        [string]$FilenamePerm, 
        [string]$VersionStr,
        [string]$VersionToCheck)
  if ((Invoke-WebRequest $url).StatusCode -eq 200) { 
    $client = new-object System.Net.WebClient
    $client.Encoding = [System.Text.Encoding]::ascii
    $client.DownloadFile("$url","$($FilenameTmp)")
    $client.Dispose()
    Write-Verbose "[.] File downloaded, checking version.."
    Write-Verbose "[.] Checking downloaded file $($FilenameTmp) .."
    $NewVersionCheck = (Check-NewerScriptVersion -Filename "$($FilenameTmp)" -VersionStr $($VersionStr) -VersionToCheck $VersionToCheck)
    if ($NewVersionCheck) {  
        Write-Host "[+] Found newer version $($NewVersionCheck), would you like to copy over this one? "
        Copy-Item "$($FilenameTmp)" "$($FilenamePerm)" -Force
        return $true
    } else {
      Write-Verbose "Continuing without updating file $($FilenamePerm)."
    }
  }  
  return $false
}

function Update-ScriptFile {   # Need a copy of this, to re-run main script
  param ([string]$url,
        [string]$FilenameTmp,
        [string]$FilenamePerm, 
        [string]$VersionStr,
        [string]$VersionToCheck)
  
  Write-Verbose "Checking for $($VersionStr) >= $($VersionToCheck) in $($FilenamePerm) .. Downloading $($url)"
  
  if ((Invoke-WebRequest $url).StatusCode -eq 200) { 
    $client = new-object System.Net.WebClient
    $client.Encoding = [System.Text.Encoding]::ascii
    $client.DownloadFile("$url","$($FilenameTmp)")
    $client.Dispose()
    Write-Verbose "[.] File downloaded, checking version.."
    Write-Verbose "[.] Checking downloaded file $($FilenameTmp) .."
    $NewVersionCheck = (Check-NewerScriptVersion -Filename "$($FilenameTmp)" -VersionStr $($VersionStr) -VersionToCheck $VersionToCheck)
    Write-Verbose "var = $NewVersionCheck"
    if ($NewVersionCheck) {  
        if (Get-YesNo "--- Found newer version $NewVersionCheck, would you like to copy over this one? ") {
          # Copy the new script over this one..
          Copy-Item "$($FilenameTmp)" "$($FilenamePerm)" -Force
          return $true
        }
    } else {
      Write-Verbose "Continuing without updating."
      return $false
    }
    return $false
  }  
}

Function Update-Script {
  # For 0.32 I am assuming $pwd is going to be the correct path
  Write-Output "[.] Checking for updated version of script on github.. Current Version = $($Version)"
  $url = "https://raw.githubusercontent.com/alexdatsko/Misc-Powershell/main/Install-SecurityFixes.ps1%20-%20Script%20which%20will%20apply%20security%20fixes%20as%20needed%20to%20each%20workstation%20resultant%20from%20a%20Qualys%20vuln%20scan/Install-SecurityFixes.ps1"
  if (Update-ScriptFile -URL $url -FilenameTmp "$($tmp)\Install-SecurityFixes.ps1" -FilenamePerm "$($pwd)\Install-SecurityFixes.ps1" -VersionStr '$Version = *' -VersionToCheck $Version) {
    Write-Host "[+] Update found, re-running script .."
    Stop-Transcript
    . "$($pwd)\Install-SecurityFixes.ps1"   # Dot source and run from here once, then exit.
    Stop-Transcript
    exit
  } else {
    Write-Output "[-] No update found for $($Version)."
    return $false
  }
}

Function Update-QIDLists {
  # For 0.32 I am assuming $pwd is going to be the correct path
  if (!($QIDsVersion)) { $QIDsVersion = "0.01" }   # If its missing, assume its super old.
  Write-Host "[.] Checking for updated QIDLists file on github.. Current Version = $($QIDsVersion)"  # Had to change to Write-Host, Write-Output is being send back to caller
  $url = "https://raw.githubusercontent.com/alexdatsko/Misc-Powershell/main/Install-SecurityFixes.ps1%20-%20Script%20which%20will%20apply%20security%20fixes%20as%20needed%20to%20each%20workstation%20resultant%20from%20a%20Qualys%20vuln%20scan/QIDLists.ps1"
  if (Update-ScriptFile -URL $url -FilenameTmp "$($tmp)\QIDLists.ps1" -FilenamePerm "$($pwd)\QIDLists.ps1" -VersionStr '$QIDsVersion = *' -VersionToCheck $QIDsVersion) {
    Write-Host "[+] Updates found, reloading QIDLists.ps1 .."
    return $true
    #Read-QIDLists  # Doesn't work in this scope, do it below in global scope
  } else {
    Write-Host "[-] No update found for $($QIDsVersion)."
    return $false
  }
  return $false
}

Function Get-OS {
    # Slower, calls 3 CIMinstances, not sure if needed anywhere
    $cs = Get-WmiObject -Class Win32_ComputerSystem
    $os = Get-WmiObject -Class Win32_OperatingSystem
    $bios = Get-WmiObject -Class Win32_BIOS

    Return [PSCustomObject]@{
        OSName = $os.Caption
        OSVersion = $os.Version
        OSBuild = $os.BuildNumber
        OSArchitecture = $os.OSArchitecture
        Manufacturer = $cs.Manufacturer
        Model = $cs.Model
        BIOSVersion = $bios.SMBIOSBIOSVersion
    }
}

Function Get-OSType {  # 1=Workstation, 2=DC, 3=Server
    $os = Get-WmiObject -Class Win32_OperatingSystem
    $ostype=$os.productType
    Return $ostype
}

Function Install-DellBiosProvider {
  # install the DellBIOSProvider powershell module if set in the config
  if ($InstallDellBIOSProvider) {
    #if ((Get-ComputerInfo).OsProductType -eq "WorkStation") {   # Not backwards compatible with Windows 8.1 etc
    if (Get-OSType -lt 2) {   # 1=Ws, 2=DC, 3=Server
      if (!(Get-InstalledModule -Name DellBIOSProvider -ErrorAction SilentlyContinue)) {
        Write-Host "[.] Trying to install the NuGet package provider.. [this may take a minute..]" 
        try { $null = Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force } catch { Write-Host "[!] Couldn't install NuGet provider!" ; return $false}
        Write-Host "[.] Trying to install the Dell BIOS provider module.. [this may take a minute..]" 
        try { Install-Module DellBIOSProvider -Force } catch { Write-Host "[!] Couldn't install DellBIOSProvder! " ; return $false}
        Write-Host "[+] Done!" -ForegroundColor Green
        return $true
      } else {
        Write-Host "[.] DellBIOSProvider already installed." 
        return $true
      }
    } else {
      Write-Verbose "[.] Non-Workstation OS found, ignoring DellBiosProvider module install"
      return $false
    }
  }
}

Function Set-DellBiosProviderDefaults {
  if ((Get-ComputerInfo).OsProductType -eq "WorkStation") { 
    if ($InstallDellBIOSProvider -and $SetWOL) {  # Set WOL settings per model
      if (!(Get-InstalledModule -Name DellBIOSProvider)) {
        Write-Host "[!] No DellBIOSProvder - Can't set WOL"
      } else {
        # For testing, just check and set these 2..
        if (Import-Module DellBIOSProvider) {
          Write-Host "[.] Checking for AcPwrRcvry=On & WakeonLAN=Enabled in DellSMBios:\ .." 
          $AcPwrRcvry=Get-Item -Path DellSMBios:\PowerManagement\AcPwrRcvry
          $WakeonLAN=Get-Item -Path DellSMBios:\PowerManagement\WakeonLAN
          if (!($AcPwrRcvry)) { 
            Write-Host "[.] Setting AcPwrRcvry=On in DellSMBios:\ .."
            try { Set-Item -Path DellSMBios:\PowerManagement\AcPwrRcvry -Value "On" } catch { Write-Host "[.] Couldn't set AcPwrRecvry=On !!" -ForegroundColor Red }
          } else {
            Write-Host "[+] Found AcPwrRcvry=On already"
          }
          if (!($WakeonLAN)) {
            Write-Host "[.] Setting WakeonLAN=Enabled in DellSMBios:\ .."
            try { Set-Item -Path DellSMBios:\PowerManagement\WakeonLAN -Value "Enabled" } catch { Write-Host "[.] Couldn't set WakeonLAN=Enabled !!" -ForegroundColor Red }
          } else {
            Write-Host "[+] Found WakeonLAN=Enabled already"
          }
          Write-Host "[+] Done w/ Dell SMBios settings." -ForegroundColor Green
        } else {
          Write-Host "[-] Dell SMBios issue running 'Import-Module DellBiosProvider' - can't set WakeOnLan etc." -ForegroundColor Red
        }
      }
    }
  } else {
    Write-Verbose "[.] Non-Workstation OS found, ignoring DellBiosProvider changes"
  }
}

################################################# CONFIG FUNCTIONS ###############################################


function Find-ConfigFileLine {  # CONTEXT Search, a match needs to be found but NOT need to be exact line, i.e '$QIDsFlash = 1,2,3,4' returns true if '#$QIDsFlash = 1,2,3,4,9999,12345' is found
  param ([string]$ConfigLine)

  $ConfigContents = (Get-Content -path $ConfigFile)
  ForEach ($str in $ConfigContents) {
    if ($str -like "*$($ConfigLine)*") {
      return $true
    }
  }
  return $false
}

function Change-ConfigFileLine {
  param ([string]$ConfigOldLine,
         [string]$ConfigNewLine)
  if (Get-YesNo "Change [$($ConfigOldLine)] in $($ConfigFile) to [$($ConfigNewLine)] ?") {
    Write-Verbose "Changing line in $($ConfigFile): `n  Old: [$($ConfigOldLine)] `n  New: [$($ConfigNewLine)]"
    $ConfigLine = (Select-String  -Path $ConfigFile -pattern $ConfigOldLine).Line
    Write-Verbose "  Found match: [$($ConfigOldLine)]"  
    Write-Verbose "  Replaced with: [$($ConfigNewLine)]"
    $ConfigContents = (Get-Content -path $ConfigFile)
    $ConfigFileNew=@()
    ForEach ($str in $ConfigContents) {
      if ($str -like "*$($ConfigLine)*") {
        Write-Verbose "Replaced: `n$str with: `n$ConfigNewLine"
        $ConfigFileNew += $ConfigNewLine
      } else {
        $ConfigFileNew += $str
      }
    }
    $ConfigFileNew | Set-Content -path $ConfigFile -Force
  }
}

function Add-ConfigFileLine {
  param ([string]$ConfigNewLine)
  if (Get-YesNo "Add [$($ConfigLine)] to $($ConfigFile) ?") {
    $ConfigContents = Get-Content -Path $ConfigFile
    $ConfigFileNew=@()
    ForEach ($str in $ConfigContents) {
      $ConfigFileNew += $str
    }
    Write-Verbose "Adding line to $($ConfigFile): `nLine: [$($ConfigNewLine)]"
    $ConfigFileNew += $ConfigNewLine
    $ConfigFileNew | Set-Content -path $ConfigFile -Force
  } else { 
    Write-Host "[-] Skipping!"
  }
}

function Remove-ConfigFileLine {  # Wrapper for Change-ConfigFileLine 
  param ([string]$ConfigOldLine)
  Change-ConfigFileLine $ConfigOldLine ""
}

function Find-LocalCSVFile {
  param ([string]$Location)    
    #write-Host "Find-LocalCSVFile $Location $OldPwd"
    # FIGURE OUT CSV Filename
    $i = 0
    if (($null -eq $Location) -or ("." -eq $Location)) { $Location = $OldPwd }
    [array]$Filenames = Get-ChildItem "$($Location)\*.csv" | ForEach-Object { $_.Name }
    $Filenames | Foreach-Object {
      Write-Host "[$i] $_" -ForegroundColor Blue
      $i += 1
    }
    if (!($Automated) -and ($i -gt 1)) {   # Don't bother picking if there is just one file..
      Write-Host "[$i] EXIT" -ForegroundColor Blue
      $Selection = Read-Host "Select file to import, [Enter=0] ?"
      if ($Selection -eq $i) { Write-Host "[-] Exiting!" -ForegroundColor Gray ; exit }
      if ($Selection -eq "") { $Selection="0" }
      $Sel = [int]$Selection
    } else { 
      $Sel=0
    }
    if (@($Filenames).length -gt 1) {
      $CSVFilename = "$($Location)\$($Filenames[$Sel])"
    } else {
      if (@($Filenames).length -gt 0) {
        $CSVFilename = "$($Location)\$($Filenames)"  # If there is only 1, we are only grabbing the first letter above.. This will get the whole filename.
      }
    }
    Write-Host "[i] Using file: $CSVFileName" -ForegroundColor Blue
    Return $CSVFileName
}

function Find-ServerCSVFile {
  param ([string]$Location)
  if (!(Test-Path "\\$($ServerName)")) {
    Write-Host "[!] Can't access '$($serverName)', skipping Find-ServerCSVFile!"
    return $null
  }
  if (!($null -eq $Location)) { $Location = "data\secaud" }  # Default to \\$servername\data\secaud if can't read from config..
  if (Test-Path "\\$($ServerName)\$($Location)") {
    $CSVFilename=(Get-ChildItem "\\$($ServerName)\$($Location)" -Filter "*.csv" | Sort-Object LastWriteTime | Select-Object -last 1).FullName
    Write-Host "[i] Found file: $CSVFileName" -ForegroundColor Blue
    return $CSVFilename 
  } else {
    return $null
  }
}

function Start-Browser {
  param ($url)
  #Start-Process "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe" -ArgumentList "$($url)"   
  Start-Process "$($url)"  # Lets just load the URL in the system default browser..
}

Function Add-VulnToQIDList {
  param ( $QIDNum,
          $QIDName,
          $QIDVar,
          $QIDsAdded)
  if ($QIDsAdded -notcontains $QIDNum) {
    #$QIDsListFile = $ConfigFile  # Default to using the ConfigFile.. Probably want to split this out again.. but leave for now
    if (Get-YesNo "New vulnerability found: [QID$($QIDNum)] - [$($QIDName)] - Add?") {
      Write-Verbose "[v] Adding to variable in $($QIDsListFile): Variable: $($QIDVar)"
      if ($Automated) { Write-Output "[QID$($QIDNum)] - [$($QIDName)] - Adding" }
      $QIDLine = (Select-String  -Path $QIDsListFile -pattern $QIDVar).Line
      Write-Verbose "[v] Found match: $QIDLine"
      $QIDLineNew = "$QIDLine,$QIDNum"  | Select-Object -Unique  
      Write-Verbose "[v] Replaced with: $QIDLineNew"
      $QIDFileNew=@()
      ForEach ($str in $(Get-Content -path $QIDsListFile)) {
        if ($str -like "*$($QIDLine)*") {
          Write-Verbose "Replaced: `n$str with: `n$QIDLineNew"
          $QIDFileNew += $QIDLineNew
        } else {
          $QIDFileNew += $str
        }
      }
      
      $QIDFileNew | Set-Content -path $QIDsListFile -Force
      # Can't run this here as the scope is local vs global..
      $QIDsAdded += $QIDNum
      Write-Verbose "[!] Adding $QIDNum to QIDsAdded. QIDsAdded = $QIDsAdded"
    }
  } else {
    Write-Output "[.] QID $QIDNum already added, skipping"
    Write-Verbose "Found $QIDNum in $QIDsAdded"
  }
}


################################################# VULN REMED FUNCTIONS ###############################################

function Remove-Software {
  param ($Products,
         $Results)
  
  foreach ($Product in $Products) { # Remove multiple products if passed..
    $Guid = $Product | Select-Object -ExpandProperty IdentifyingNumber
    $Name = $Product | Select-Object -ExpandProperty Name
    if (Get-YesNo "Uninstall $Name - $Guid ") { 
        Write-Host "[.] Removing $Guid (Waiting max of 30 seconds after).. Searching WMI first"
        $x=0
        cmd /c "msiexec /x $Guid /quiet /qn"
        Write-Host "[.] Checking for removal of $Guid .." -ForegroundColor White -NoNewline
        while ($x -lt 5) {
            Start-sleep 5
            Write-Host "." -ForegroundColor White -NoNewLine
            $x+=1
            $Products = (get-wmiobject Win32_Product | Where-Object { $_.IdentifyingNumber -like "$Guid"}) 
            if (!($Products)) { 
              $x=5 
              Write-Host "`n[!] $Guid removed successfully!`n" -ForegroundColor Green
            }
        }
        if ($Products) {
            Write-Host "[!] Error removing $($Products.Guid) (or may have taken longer than 30s) !!`n" -ForegroundColor Red
      }
    } else {
      Write-Host "[.] Not found in WMI, searching Uninstaller registry.."
        if (Get-ItemProperty -Path HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\* |
            Where-Object DisplayName -eq CCleaner -OutVariable Results) {
            & "$($Results.InstallLocation)\uninst.exe" /S
        }
    }
  }
}


function Remove-RegistryItem {
  param ([string]$Path)

  Write-Host "[ ] Checking registry for: `n  $Path  :" -ForegroundColor Gray
  try {
    $result = (Get-ItemProperty -Path $Path -ErrorAction SilentlyContinue)
  } catch { 
    Write-Host "[!] Couldn't find Registry entry!! `r`n  $Path" -ForegroundColor Green
  }
  if ($result) {
    Write-Host "[.] Removing registry item: `n  $Path  :" -ForegroundColor White
    try { # Remove $Path\*
      Remove-Item -Path $Path\* -Recurse
    } catch {
      Write-Host "[!] Couldn't run Remove-Item -Path $Path\* -Recurse !!" -ForegroundColor Red
    }
    try { # Remove $Path itself
      Remove-Item -Path $Path 
    } catch {
      Write-Host "[!] Couldn't run Remove-Item -Path $Path !!" -ForegroundColor Red
    }
    try { # Check and make sure its removed?
      $result = (Get-ItemProperty -Path $Path -ErrorAction SilentlyContinue)
    } catch {
      Write-Host "[.] Complete. Registry entry verified removed: `n  $Path" -ForegroundColor Green
    }
    if ($result) {
      Write-Host "[!] Something went wrong. Not successful removing $Path .."  -ForegroundColor Red
    }
  } else {
    Write-Host "[.] Couldn't find Registry entry. Clean." -ForegroundColor Green
  }
}

function Download-NewestAdobeReader {
    # determining the latest version of Reader
    $session = New-Object Microsoft.PowerShell.Commands.WebRequestSession
    $session.UserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.67 Safari/537.36"
    $result = Invoke-RestMethod -Uri "https://rdc.adobe.io/reader/products?lang=mui&site=enterprise&os=Windows%2011&country=US&nativeOs=Windows%2010&api_key=dc-get-adobereader-cdn" `
        -WebSession $session `
        -Headers @{
            "Accept"="*/*"
            "Accept-Encoding"="gzip, deflate, br"
            "Accept-Language"="en-US,en;q=0.9"
            "Origin"="https://get.adobe.com"
            "Referer"="https://get.adobe.com/"
            "Sec-Fetch-Dest"="empty"
            "Sec-Fetch-Mode"="cors"
            "Sec-Fetch-Site"="cross-site"
            "sec-ch-ua"="`" Not A;Brand`";v=`"99`", `"Chromium`";v=`"101`", `"Google Chrome`";v=`"101`""
            "sec-ch-ua-mobile"="?0"
            "sec-ch-ua-platform"="`"Windows`""
            "x-api-key"="dc-get-adobereader-cdn"
    }

    $version = $result.products.reader[0].version
    $version = $version.replace('.','')

    # downloading
    $URI = "https://ardownload2.adobe.com/pub/adobe/acrobat/win/AcrobatDC/$Version/AcroRdrDCx64$($Version)_MUI.exe"
    #$OutFile = Join-Path $tmp "AcroRdrDCx64$($version)_MUI.exe"
    $OutFile = "$($tmp)\readerdc.exe"
    Write-Host "[.] Downloading version $version from $URI to $OutFile"
    Invoke-WebRequest -Uri $URI -OutFile $OutFile -Verbose

    Write-Output "[!] Download complete."
    return $OutFile
}

function Get-ServicePermIssues {
  param ([string]$Results)

  $ServicePermIssues = @()
  $maxresults = (([regex]::Matches($Results, "------------------------------------------------------------")).count / 2) # Determine the number of service permission issues
  $ResultsSplit = $Results.split("`n").split("`r").split("`t") -split " {2,}"   # There are no more `r or `n newlines now in BTS Qualys reports- as of 3-13-23.  So.. Also split at multiple spaces to catch these, there is likely not one in the middle of an exe filename or path, HOPEFULLY..
    # Shouldn't really matter how many lines there are if we are only looking for C:\ or _:\ separated by 2 or more spaces.. This should work!
  Write-Verbose "ServicePermIssue ResultsSplit (count): $($ResultsSplit.Count)"
  foreach ($result in $ResultsSplit) {
    #Write-Verbose "ServicePermIssueResult: $result"
    if ($result -match '\:\\') {     # This SHOULD be safe for now, due to the format accesschk.exe results
      $ServicePermIssues += $result.trim()
    } else {
      #Write-Verbose "Unmatched result: $result"
    }
  }
  Write-Verbose "Service Permission Issues found: $ServicePermIssues"
  return $ServicePermIssues
}

Function Check-ServiceFilePerms {
param ([string]$FilesToCheck)
  $RelevantList = @("Everyone","BUILTIN\Users","BUILTIN\Authenticated Users","BUILTIN\Domain Users")
  $Output = @() 
  ForEach ($FileToCheck in $FilesToCheck) { 
    $Acl = Get-Acl -Path $FileToCheck   #.FullName   #Not using object from gci
    ForEach ($Access in $Acl.Access) { 
      Write-Verbose "Identity for $($FileToCheck):       $($Access.IdentityReference)"
      #$RelevantList
      if ($RelevantList -contains $Access.IdentityReference) {
        #$Access.FileSystemRights
        if (($Access.FileSystemRights -match "FullControl") -or ($Access.FileSystemRights -like "*Write*")) {
          $Properties = [ordered]@{'Folder Name'=$FileToCheck;'Group/User'=$Access.IdentityReference;'Permissions'=$Access.FileSystemRights;'Inherited'=$Access.IsInherited} 
          $Output += New-Object -TypeName PSObject -Property $Properties 
        }
      }
    }
  }
  Return $Output   # If something is returned, this is not good
}

Function Check-FilePerms {
param ([string]$FilesToCheck)
  #$RelevantList = @("Everyone","Users","Authenticated Users","Domain Users")
  Write-Verbose "Checking file perms for $FilesToCheck .."
  $Output = @() 
  ForEach ($FileToCheck in $FilesToCheck) { 
    $Acl = Get-Acl -Path $FileToCheck   #.FullName   #Not using object from gci
    ForEach ($Access in $Acl.Access) { 
      $Properties = [ordered]@{'Folder Name'=$FileToCheck;'Group/User'=$Access.IdentityReference;'Permissions'=$Access.FileSystemRights;'Inherited'=$Access.IsInherited} 
      $Output += New-Object -TypeName PSObject -Property $Properties 
    }
  }
  Return $Output
} 

function Set-AdminACLsFolder {
param ([string]$RedirectPath)
    $ErrorActionPreference="SilentlyContinue"

    #Using provided path, gather array of user folders to populate usernames
    $list = "$RedirectPath" | get-childitem
    Foreach ($l in $list) {
        #username is name of folder
        $user = $l.name
        # Filepath is folder.FullName
        $path = $l.FullName
        # Force recursive ownership for BUILTIN/Administrators of the folder using builtin Takeown.exe
        TAKEOWN /F $path /A /R /D "Y"
        # Apply full access permissions for both the user and administrators with ICACLS
        ICACLS $path /grant Administrators:F /T 
        #Use AD to check whether user is active/exists and act accordingly
        If (Get-ADUser $user) {
            ICACLS $path /grant "${user}:F" /T 
            # Apply ownership back to user with ICACLS, again, if still exists in AD
            ICACLS $path /setowner "$user" /T
        }
    }
}

function Delete-Folder {
  param ([string]$FolderToDelete,
         $Results)

  if (Test-Path $FolderToDelete) {
    if (Get-YesNo "Found Folder $($FolderToDelete). Try to remove? ") { 
      takeown.exe /a /r /d Y /f $($FolderToDelete)
      Remove-Item $FolderToDelete -Force -Recurse
      # Or, try { and delete with psexec like below function.. Will come back to this if needed.
    } else {
      Write-Host "`n[!] NOT FIXED. $FolderToDelete can't be removed.  Manual intervention will be required!"
      return $false
    }
  } else {
    Write-Host "`n[!] $FolderToDelete cannot be found with Test-Path, or might not be a Container type.  (Maybe this has been fixed already?)"
    return $true
  }
  if (Test-Path $FolderToDelete) {
    Write-Host "`n[-] NOT FIXED. $FolderToDelete still found."
    return $false
  } else {
    Write-Host "`n[+] FIXED. $FolderToDelete has been removed."
    return $true
  }
}

function Delete-File {
  param ($FileToDelete,
         $Results)
  
  if (Test-Path $FileToDelete -PathType Leaf) {
    if (Get-YesNo "Found file $($FileToDelete). Try to remove? ") { 
      Remove-Item $FileToDelete -Force  -ErrorAction SilentlyContinue
      if (Test-Path $FileToDelete -PathType Leaf) { # If it fails:
        Write-Host "[!] Could not remove file with Remove-Item -Force .. Trying Psexec method.."
        if (!(Test-Path -Path "$($oldpwd)\psexec.exe")) {
          Write-Output "[!] Cannot run psexec.exe - not found in $($oldpwd)\psexec.exe by Test-Path ! Fix manually.."
        } else {
          Copy-Item -Path "$($oldpwd)\psexec.exe" -Destination "$($tmp)\psexec.exe" -Force
          
          $exe = "$($tmp)\psexec.exe"
          $params = "-accepteula -s cmd.exe /c 'del /s /f /q ""$($FileToDelete)""'"
          Write-Output "Running: $exe $params"
          $process = Start-Process -FilePath $exe -ArgumentList $params -Wait -Passthru -WindowStyle Hidden
          $process.StandardOutput
          $process.StandardError
          
        }
      }
    } else {
      Write-Output "[!] NOT FIXED. $FileToDelete won't be removed, user chose not to.  Manual intervention will be required!"
      return $false
    }
  } else {
    Write-Output "[!] $FileToDelete cannot be found with Test-Path, or might not be a Leaf type.  (Maybe this has been fixed already?)"
    return $true
  }
  if (Test-Path $FileToDelete -PathType Leaf) {
    Write-Output "[-] NOT FIXED. $FileToDelete still found."
  } else {
    Write-Output "[+] FIXED. $FileToDelete has been removed."
  }
}

function Get-PathRaw {
  param ([string]$ThisPath)
  return Split-Path ($ThisPath.replace("%appdata%","$env:appdata").replace("%computername%","$env:computername").replace("%home%","$env:home").replace("%systemroot%","$env:systemroot").replace("%systemdrive%","$env:systemdrive").replace("%programdata%","$env:programdata").replace("%programfiles%","$env:programfiles").replace("%programfiles(x86)%","$env:programfiles(x86)").replace("%programw6432%","$env:programw6432"))
}

function Parse-ResultsFolder {  
  param ($Results)
 
  $Paths = New-Object System.Collections.Generic.List[string]
  $x = 0
  Write-Verbose "Results: $Results"
  $count = [regex]::Matches($Results, "Version is").Count
  Write-Verbose "Count of 'Version is': $count"
  if ($count -gt 0) {
    while ($x -le $count) {
      $PathResults = Split-Path ((($Results -split('Version is'))[0]).trim())
      Write-Verbose "PathResults : $PathResults"
      if ($null -ne $PathResults) {
        $PathRaw = Get-PathRaw $PathResults
        Write-Verbose "PathRaw : $PathRaw"
        if ($count -gt 1) {
          if (!($Paths -contains $PathRaw)) {
            $Paths.Add($PathRaw)
          } else {
            Write-Verbose "PathRaw ($PathRaw) matches existing within : $Paths - skipping."
          }
        } else {
          return $PathRaw
        }
      }
      $x += 1
    }
  }  else {
    return $false
  }
  return $Paths  
} 


function Parse-ResultsFile {  
    [CmdletBinding()]
    param ($Results)
 
  $Paths = New-Object System.Collections.Generic.List[string]
  $x = 0
  Write-Verbose "Results: $Results"
  $count = [regex]::Matches($Results, "Version is").Count
  Write-Verbose "Count of 'Version is': $count"
  if ($count -gt 0) {
    while ($x -le $count) {
      $PathResults = (($Results -split('Version is'))[0]).trim()
      Write-Verbose "PathResults : $PathResults"
      if ($null -ne $PathResults) {
        $PathRaw = Get-PathRaw $PathResults
        Write-Verbose "PathRaw : $PathRaw"
        if ($count -gt 1) {
          if (!($Paths -contains $PathRaw)) {
            $Paths.Add($PathRaw)
          } else {
            Write-Verbose "PathRaw ($PathRaw) matches existing within : $Paths - skipping."
          }
        } else {
          return $PathRaw
        }
      }
      $x += 1
    }
  }  else {
    return $false
  }
  return $Paths  
}

function Backup-BitlockerKeys {
  if ($BackupBitlocker) {
    if (Test-Path "C:\Windows\System32\manage-bde.exe") {  # If this exists, bitlocker role is at least installed
      if ((Get-BitlockerVolume -MountPoint 'C:').VolumeStatus -eq "FullyDecrypted") {
        Write-Host "[!] $($BLV) not Bitlocker encrypted!"
        return $false
      } else {
        Write-Host "[!] Found C: Bitlockered."
      }
      $BLVs = (Get-BitLockerVolume).MountPoint
      foreach ($BLV in $BLVs) { 
        if (Get-BitLockerVolume -MountPoint $BLV -ErrorAction SilentlyContinue) {
          try {
            Write-Output "[.] Backing up Bitlocker Keys to AD.."
            Backup-BitLockerKeyProtector -MountPoint $BLV -KeyProtectorId (Get-BitLockerVolume -MountPoint $BLV).KeyProtector[1].KeyProtectorId
            return $true
          } catch { 
            Write-Output "[!] ERROR: Could not access BitlockerKeyProtector. Is drive $BLV encrypted? "
            Get-BitLockerVolume
            return $false
          }
        }
      }
    } else {
      Write-Output "[-] Skipping backup of Bitlocker keys."
      return $false
    }
  }
}

function Check-FileVersion {
  param ([string]$FileName)

  return (Get-Item $FileName).VersionInfo.FileVersionRaw
}


################################################################################################################## MAIN ############################################################################################################
################################################################################################################## MAIN ############################################################################################################
################################################################################################################## MAIN ############################################################################################################

$hostname = $env:COMPUTERNAME
$datetime = Get-Date -Format "yyyy-MM-dd HH:mm:ss K"
$datetimedateonly = Get-Date -Format "yyyy-MM-dd"
$osinstalldate = ([WMI]'').ConvertToDateTime((Get-WmiObject Win32_OperatingSystem).InstallDate) | get-date -Format MM/dd/yyyy
$serialnumber = (wmic bios get serialnumber)
Write-Host "`r`n================================================================" -ForegroundColor DarkCyan
Write-Host "[i] Install-SecurityFixes.ps1" -ForegroundColor Cyan
Write-Host "[i]   $($VersionInfo)" -ForegroundColor Cyan
Write-Host "[i]   Alex Datsko - alex.datsko@mmeconsulting.com" -ForegroundColor Cyan
Write-Host "[i] Date / Time : $datetime" -ForegroundColor Cyan
Write-Host "[i] Computername : $hostname " -ForegroundColor Cyan
Write-Host "[i] SerialNumber : $serialnumber " -ForegroundColor Cyan
Write-Host "[i] OS Install Date : $osinstalldate " -ForegroundColor Cyan
if (([WMI]'').ConvertToDateTime((Get-WmiObject Win32_OperatingSystem).InstallDate) -ge (Get-Date $datetimedateonly).AddDays(0-$IgnoreDaysOld)) {
  if (!(Get-YesNo "$osinstalldate is within $IgnoreDaysOld days, continue?")) {
    Write-Host "[!] Exiting" -ForegroundColor White
    Stop-Transcript
    exit
  }
}

# These variables should be referenced globally:
. "$($ConfigFile)"
. "$($QIDsListFile)"

# Check for newer version of script before anything..
Update-Script  # CHECKS FOR SCRIPT UPDATES, UPDATES AND RERUNS IF POSSIBLE
if (Update-QIDLists) { . "$($QIDsListFile)" }

# Lets check the Config first for $ServerName, as that is our default..
if ($ServerName) {
  if (Test-Connection -ComputerName $ServerName -Count 2 -Delay 1 -Quiet -ErrorAction SilentlyContinue) {
    Write-Output "[.] Checking location \\$($ServerName)\$($CSVLocation) .."
    if (Get-Item "\\$($ServerName)\$($CSVLocation)\Install-SecurityFixes.ps1") {
      Write-Host "[.] Found \\$($ServerName)\$($CSVLocation)\Install-SecurityFixes.ps1 .. Cleared to proceed." -ForegroundColor Green
    }
  } else {
    # Lets also check SERVER in case config is wrong?
    Write-Output "[.] Checking default location \\SERVER\Data\SecAud .."
    if (Test-Connection -ComputerName "SERVER" -Count 2 -Delay 1 -Quiet -ErrorAction SilentlyContinue) {
      if (Get-Item "\\SERVER\Data\SecAud\Install-SecurityFixes.ps1") {
        $ServerName = "SERVER"
        $CSVLocation = "Data\SecAud"
        Write-Host "[.] Found \\$($ServerName)\$($CSVLocation)}\Install-SecurityFixes.ps1 .. Cleared to proceed." -ForegroundColor Green
      }
    }    
  }
} else {  # Can't ping $ServerName, lets see if there is a good location, or localhost?
  $ServerName = Read-Host "[!] Couldn't ping SERVER or '$($ServerName)' .. please enter the server name where we can find the .CSV file, or press enter to read it out of the current folder: "
  if (!($ServerName)) { 
    $ServerName = "$($env:computername)"
  }
}

if (Get-OSType -eq 1) {
  Install-DellBiosProvider  # Will only run if value is set in Config
  Set-DellBiosProviderDefaults # Will only run if value is set in Config  
}
Backup-BitlockerKeys # Try to Backup Bitlocker recovery keys to AD

################# ( READ IN CSV AND PROCESS ) #####################

if (!(Test-Path $($tmp))) {
  try {
    Write-Host "[ ] Creating $($tmp) .." -ForegroundColor Gray
    $null=New-Item $($tmp) -ItemType Directory -ErrorAction SilentlyContinue
  } catch {
    Write-Host "[X] Couldn't create folder $($tmp) !! This is needed for temporary storage." -ForegroundColor Red
    Exit
  }
}
$oldpwd=(Get-Location).Path
Set-Location "$($tmp)"  # Cmd.exe cannot be run from a server share

$CSVFilename = Find-ServerCSVFile "$($ServerName)\$($CSVLocation)"
if ($null -eq $CSVFilename) {
  $CSVFilename = Find-LocalCSVFile "."
}
# READ CSV
if ($null -eq $CSVFilename) {
  Write-Host "[X] Couldn't find CSV file : $CSVFilename " -ForegroundColor Red
  Exit
} else {
  try {
    $CSVData = Import-CSV $CSVFilename | sort "Vulnerability Description"
  } catch {
    Write-Host "[X] Couldn't open CSV file : $CSVFilename " -ForegroundColor Red
    sl $pwd
    Exit
  }
  if (!($CSVData)) {
    Write-Host "[X] Couldn't read CSV data from file : $CSVFilename " -ForegroundColor Red
    Exit
  } else {
    Write-Host "[i] Read CSV data from : $CSVFilename " -ForegroundColor Cyan
  }
}

######## Find if there are any new vulnerabilities not listed ########

$Rows = @()
$QIDsAdded = @()
$CSVData | ForEach-Object {
# Search by title:
  $QID=($_.QID).Replace('.0','') 
  if ($QIDsAdded -notcontains [int]$QID) {
    if ($_.Title -like "Apple iCloud for Windows*") {
      if (!($QIDsAppleiCloud -contains $QID)) {
        Add-VulnToQIDList $QID $_.Title  'QIDsAddedQIDsAppleiTunes' 
        . $($QIDsListFile)
        $QIDsAdded+=[int]$QID
      }
    }
    if ($_.Title -like "Apple iTunes for Windows*") {
      if (!($QIDsAppleiTunes -contains $QID)) {
        Add-VulnToQIDList $QID $_.Title  'QIDsAppleiTunes' 
        . $($QIDsListFile)
        $QIDsAdded+=[int]$QID
      }
    }
    if ($_.Title -like "Chrome*") {
      if (!($QIDsTeamviewer -contains $QID)) {
        Add-VulnToQIDList $QID $_.Title  'QIDsTeamViewer' 
        . $($QIDsListFile)
        $QIDsAdded+=[int]$QID
      }
    }
    if ($_.Title -like "Firefox*") {
      if (!($QIDsFirefox -contains $QID)) {
        Add-VulnToQIDList $QID $_.Title  'QIDsFirefox'
        . $($QIDsListFile)
        $QIDsAdded+=[int]$QID
      }
    }
    if ($_.Title -like "Zoom Client*") {
      if (!($QIDsZoom -contains $QID)) {
        Add-VulnToQIDList $QID $_.Title  'QIDsZoom'
        . $($QIDsListFile)
        $QIDsAdded+=[int]$QID
      }
    }
    if ($_.Title -like "TeamViewer*") {
      if (!($QIDsTeamviewer -contains $QID)) {
        Add-VulnToQIDList $QID $_.Title  'QIDsTeamViewer'
        . $($QIDsListFile)
        $QIDsAdded+=[int]$QID
      }
    }  
    if ($_.Title -like "Dropbox*") {
      if (!($QIDsDropbox -contains $QID)) {
        Add-VulnToQIDList $QID $_.Title  'QIDsDropbox'
        . $($QIDsListFile)
        $QIDsAdded+=[int]$QID
      }
    }
    if ($_.Title -like "Oracle Java*") {            ########
      if (!($QIDsOracleJava -contains $QID)) {
        Add-VulnToQIDList $QID $_.Title  'QIDsOracleJava' 
        . $($QIDsListFile)
        $QIDsAdded+=[int]$QID
      }
    }
    if ($_.Title -like "Adopt Open JDK*") {             ############
      if (!($QIDsAdoptOpenJDK -contains $QID)) {
        Add-VulnToQIDList $QID $_.Title  'QIDsAdoptOpenJDK' 
        . $($QIDsListFile)
        $QIDsAdded+=[int]$QID
      }
    }
    if ($_.Title -like "VirtualBox*") {
      if (!($QIDsVirtualBox -contains $QID)) {
        Add-VulnToQIDList $QID $_.Title  'QIDsVirtualBox'
        . $($QIDsListFile)
        $QIDsAdded+=[int]$QID
      }
    }
    if ($_.Title -like "Adobe Reader*") {  
      if (!($QIDsAdobeReader -contains $QID)) {
        Add-VulnToQIDList $QID $_.Title  'QIDsAdobeReader'
        $QIDsAdded+=[int]$QID
      }
    }
    if ($_.Title -like "Intel Graphics*") {
      if (!($QIDsIntelGraphicsDriver -contains $QID)) {
        Add-VulnToQIDList $QID $_.Title  'QIDsIntelGraphicsDriver'
        . $($QIDsListFile)
        $QIDsAdded+=[int]$QID
      }
    }
    if ($_.Title -like "NVIDIA*") {
      if (!($QIDsNVIDIA -contains $QID)) { 
        Add-VulnToQIDList $QID $_.Title  'QIDsNVIDIA' 
        . $($QIDsListFile)
        $QIDsAdded+=[int]$QID
      }
    }
    if ($_.Title -like "Dell Client*") {
      if (!($QIDsDellCommandUpdate -contains $QID)) {
        Add-VulnToQIDList $QID $_.Title  'QIDsDellCommandUpdate' 
        . $($QIDsListFile)
        $QIDsAdded+=[int]$QID
      }
    }
    if ($_.Title -like "Ghostscript*") {
      if (!($QIDsGhostscript -contains $QID)) {
        Add-VulnToQIDList $QID $_.Title  'QIDsGhostScript' 
        . $($QIDsListFile)
        $QIDsAdded+=[int]$QID
      }
    }

  # Search by title:
    if ($_.Results -like "Microsoft vulnerable Microsoft.*") {
      if (!($QIDsUpdateMicrosoftStoreApps -contains $QID)) {
        Add-VulnToQIDList $QID $_.Title  'QIDsUpdateMicrosoftStoreApps' $QIDsAdded
        . $($QIDsListFile)
        $QIDsAdded+=[int]$QID
      }
    }
  }
}
Write-Output "[.] Done checking for new vulns.`n"

############################### Find applicable rows to this machine #################################
# FIND ROWS WITH HOSTNAME = $Hostname
$Rows = @()
$CSVData | ForEach-Object {
  if (($_.NetBIOS.ToUpper()) -eq $Hostname.ToUpper()) {
    $Rows += $_
  }
}

Write-Host "[i] CSV Rows applicable to $Hostname : $($Rows.Count)" -ForegroundColor Cyan
if ($Rows.Count -lt 1) {
  Write-Host "[X] There are no rows applicable to $hostname !! Exiting.." -ForegroundColor Red
  Exit
}
# $Rows

# FIND QIDS FROM THESE ROWS
$QIDs = @()
$QIDsVerbose = @()
$Rows | ForEach-Object {
  $ThisQID=[int]$_.QID.replace(".0","")
  if ($QIDsIgnored -notcontains $ThisQID) {  # FIND QIDS TO IGNORE
    $QIDs += $ThisQID
    $QIDsVerbose += "[QID$($ThisQID) - [$($_.Title)]"
    $Results=($_.Results)
    # ----------------- GRAB OTHER IMPORTANT INFO FROM THIS ROW IF NEEDED! ------------------
    switch ([int]$ThisQID) {
      372294 {
        Write-Verbose "Service permission issues found."
        Write-Verbose "Results: $Results"
        $ServicePermIssues = Get-ServicePermIssues -Results $Results
        Write-Verbose "`nServicePermIssues: "
        foreach ($issue in $ServicePermIssues) { 
          Write-Verbose "Issue: $issue"
        }
      }
    }
  } else {
    $QIDsVerbose += "[Ignored: QID$($ThisQID) - [$($_.Title)]"
  }
}

# DISPLAY QIDs FOUND FOR THIS HOST
Write-Host "[i] QIDs found: $($QIDs.Count) - $QIDs" -ForegroundColor Cyan
ForEach ($Qv in $QIDsVerbose) {  # Show ignored QIDs only if -verbose parameter is supplied
  Write-Verbose $Qv
}

if (!($QIDs)) {
  Write-Host "[X] No QIDs found to fix for $hostname !! Exiting " -ForegroundColor Red
  exit
}
Write-Host "`n"

############################################################################################################################################################################################
# APPLY FIXES FOR QIDs

foreach ($QID in $QIDs) {
    $ThisQID = $QID
    $ThisTitle = (($Rows | Where-Object { $_.QID -eq $ThisQID }) | Select-Object -First 1)."Vulnerability Description"
    $Results = (($Rows | Where-Object { $_.QID -eq $ThisQID }) | Select-Object -First 1)."Results"
    switch ([int]$QID)
    {
      376023 { 
        if (Get-YesNo "$_ Remove Dell SupportAssist ? " -Results $Results) {
          $guid = (Get-Package | Where-Object{$_.Name -like "*SupportAssist*"})
          if ($guid) {  ($guid | Select-Object -expand FastPackageReference).replace("}","").replace("{","")  }
          msiexec /x $guid /qn /L*V "$($tmp)\SupportAssist.log" REBOOT=R
          
          # This might require interaction, in which case run this:
          msiexec /x $guid /L*V "$($tmp)\SupportAssist.log"

          # Or:
          # ([wmi]"\\$env:computername\root\cimv2:Win32_Product.$guid").uninstall()   
        }
      }
      105228 { 
        if (Get-YesNo "$_ Disable guest account and rename to NoVisitors ? " -Results $Results) {
            if ($OSVersion -ge 7) {
              Disable-LocalUser -Name "Guest"
              Write-Host "[.] Guest account disabled with: 'Disable-LocalUser -Name ""Guest""'"
              Rename-LocalUser -Name "Guest" -NewName "NoVisitors" | Disable-LocalUser
              Write-Host "[.] Guest account renamed with: Rename-LocalUser -Name ""Guest"" -NewName ""NoVisitors"" | Disable-LocalUser"
            } else {
              cmd /c 'net user Guest /active:no'
              Write-Host "[.] Guest account disabled with: 'net user Guest /active:no'"
              cmd /c 'wmic useraccount where name="Guest" rename NoVisitors'
              Write-Host "[.] Guest account renamed with: 'wmic useraccount where name=""Guest"" rename NoVisitors'"
            }
        }
      }
      { $QIDsSpectreMeltdown -contains $_ } {
        if (Get-YesNo "$_ Fix spectre4/meltdown ? " -Results $Results) {
            cmd /c 'reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management" /v FeatureSettingsOverride /t REG_DWORD /d 72 /f'
            cmd /c 'reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management" /v FeatureSettingsOverrideMask /t REG_DWORD /d 3 /f'
            #cmd /c 'reg query "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Virtualization" '
            cmd /c 'reg add "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Virtualization" /v MinVmVersionForCpuBasedMitigations /t REG_SZ /d "1.0" /f'
            $QIDsSpectreMeltdown = 1
        } else { $QIDsSpectreMeltdown = 1 }
      }
      110414 {
        if (Get-YesNo "$_ Fix Microsoft Outlook Denial of Service (DoS) Vulnerability Security Update August 2022 ? " -Results $Results) { 
          Invoke-WebRequest "https://catalog.s.download.windowsupdate.com/c/msdownload/update/software/secu/2022/07/outlook-x-none_1763a730d8058df2248775ddd907e32694c80f52.cab" -outfile "$($tmp)\outlook-x-none.cab"
          cmd /c "C:\Windows\System32\expand.exe -F:* $($tmp)\outlook-x-none.cab $($tmp)"
          cmd /c "msiexec /p $($tmp)\outlook-x-none.msp /qn"
        }
      }
      110413 {
        if (Get-YesNo "$_ Fix Microsoft Office Security Update for August 2022? " -Results $Results) { 
          Write-Host "[.] Downloading CAB: https://catalog.s.download.windowsupdate.com/c/msdownload/update/software/secu/2022/07/msohevi-x-none_a317be1090606cd424132687bc627baffec45292.cab .."
          Invoke-WebRequest "https://catalog.s.download.windowsupdate.com/c/msdownload/update/software/secu/2022/07/msohevi-x-none_a317be1090606cd424132687bc627baffec45292.cab" -outfile "$($tmp)\msohevi-x-none.msp"
          Write-Host "[.] Extracting cab: C:\Windows\System32\expand.exe -F: $($tmp)\msohevi-x-none.msp $($tmp)"
          cmd /c "C:\Windows\System32\expand.exe -F:* $($tmp)\msohevi-x-none.msp $($tmp)"
          Write-Host "[.] Installing patch: $($tmp)\msohevi-x-none.msp"
          cmd /c "msiexec /p $($tmp)\msohevi-x-none.msp /qn"

          Write-Host "[.] Downloading CAB: https://catalog.s.download.windowsupdate.com/c/msdownload/update/software/secu/2022/07/excel-x-none_355a1faf5d9fb095c7be862eb16105cfb2f24ca2.cab .."
          Invoke-WebRequest "https://catalog.s.download.windowsupdate.com/c/msdownload/update/software/secu/2022/07/excel-x-none_355a1faf5d9fb095c7be862eb16105cfb2f24ca2.cab" -outfile "$($tmp)\excel-x-none.cab"
          Write-Host "[.] Extracting cab: C:\Windows\System32\expand.exe -F: $($tmp)\excel-x-none.msp $($tmp)"
          cmd /c "C:\Windows\System32\expand.exe -F:* $($tmp)\excel-x-none.msp $($tmp)"
          Write-Host "[.] Installing patch: $($tmp)\excel-x-none.msp"
          cmd /c "msiexec /p $($tmp)\excel-x-none.msp /qn"

        }
      }
      110412 {
        if (Get-YesNo "$_ Fix Microsoft Office Security Update for July 2022? " -Results $Results) { 
          Write-Host "[.] Downloading CAB: https://catalog.s.download.windowsupdate.com/c/msdownload/update/software/secu/2022/07/excel-x-none_355a1faf5d9fb095c7be862eb16105cfb2f24ca2.cab .."
          Invoke-WebRequest "http://catalog.s.download.windowsupdate.com/d/msdownload/update/software/secu/2022/06/vbe7-x-none_1b914b1d60119d31176614c2414c0e372756076e.cab" -outfile "$($tmp)\vbe7-x-none.cab"
          Write-Host "[.] Extracting cab: C:\Windows\System32\expand.exe -F: $($tmp)\vbe7-x-none.msp $($tmp)"
          cmd /c "C:\Windows\System32\expand.exe -F:* $($tmp)\excel-x-none.msp $($tmp)"
          Write-Host "[.] Installing patch: $($tmp)\vbe7-x-none.msp"
          cmd /c "msiexec /p $($tmp)\vbe7-x-none.msp /qn"
        }
      }
      91738 {
        if (Get-YesNo "$_  - fix ipv4 source routing bug/ipv6 global reassemblylimit? " -Results $Results) { 
            netsh int ipv4 set global sourceroutingbehavior=drop
            Netsh int ipv6 set global reassemblylimit=0
        }
      }
      375589 {  
        if (Get-YesNo "$_ - Delete Dell DbUtil_2_3.sys ? " -Results $Results) {
            cmd /c 'del c:\users\dbutil_2_3*.sys /s /f /q'
        }
      }
      100413 {
        if (Get-YesNo "$_ CVE-2017-8529 - IE Feature_Enable_Print_Info_Disclosure fix ? " -Results $Results) {
            cmd /c 'reg add "HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_ENABLE_PRINT_INFO_DISCLOSURE_FIX" /f'
            cmd /c 'reg add "HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_ENABLE_PRINT_INFO_DISCLOSURE_FIX" /v iexplore.exe /t REG_DWORD /d 1 /f'
        }
      }
      { 105170,105171 -contains $_ } { 
        if (Get-YesNo "$_ - Windows Explorer Autoplay not Disabled ? " -Results $Results) {
            #cmd /c 'reg add "HKEY_LOCAL_MACHINE\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer\"  /v NoDriveTypeAutoRun /t REG_DWORD /d 255 /f'
            #cmd /c 'reg add "HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\policies\Explorer\"  /v NoDriveTypeAutoRun /t REG_DWORD /d 255 /f'
            # QID105170,105171 - disable autoplay
            $path ='HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\policies\Explorer'
            $path2 = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\policies\Explorer'
            if (!(Test-Path $path)) {
              Write-Output "[.] Creating $($path) as it was not found.."
              New-Item -Path $path –Force
            }
            if (!(Test-Path $path2)) {
              Write-Output "[.] Creating $($path2) as it was not found.."
              New-Item -Path $path2 –Force
            }
            Set-ItemProperty $path -Name NoDriveTypeAutorun -Type DWord -Value 0xFF
            Set-ItemProperty $path -Name NoAutorun -Type DWord -Value 0x1
            Set-ItemProperty $path2 -Name NoDriveTypeAutorun -Type DWord -Value 0xFF
            Set-ItemProperty $path2 -Name NoAutorun -Type DWord -Value 0x1
        }
      }
      90044 {
        if (Get-YesNo "$_ - Allowed SMB Null session ? " -Results $Results) {
            cmd /c 'reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Lsa" /v RestrictAnonymous /t REG_DWORD /d 1 /f'
            cmd /c 'reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Lsa" /v RestrictAnonymousSAM /t REG_DWORD /d 1 /f'
            cmd /c 'reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Lsa" /v EveryoneIncludesAnonymous /t REG_DWORD /d 0 /f'
        }
      }
      90007 {
        if (Get-YesNo "$_ - Enabled Cached Logon Credential ? " -Results $Results) {
          cmd /c 'reg query "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" /v CachedLogonsCount'  
          cmd /c 'reg add "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" /v CachedLogonsCount /t REG_SZ /d 0 /f'
        }
      }
      90043 {
        if (Get-YesNo "$_ - SMB Signing Disabled / Not required (Both LanManWorkstation and LanManServer)) ? " -Results $Results) {
            cmd /c 'reg add "HKEY_LOCAL_MACHINE\System\CurrentControlSet\Services\LanManWorkstation\Parameters"  /v EnableSecuritySignature /t REG_DWORD /d 1 /f'
            cmd /c 'reg add "HKEY_LOCAL_MACHINE\System\CurrentControlSet\Services\LanManWorkstation\Parameters"  /v RequireSecuritySignature /t REG_DWORD /d 1 /f'
            cmd /c 'reg add "HKEY_LOCAL_MACHINE\System\CurrentControlSet\Services\LanManServer\Parameters"  /v EnableSecuritySignature /t REG_DWORD /d 1 /f'
            cmd /c 'reg add "HKEY_LOCAL_MACHINE\System\CurrentControlSet\Services\LanManServer\Parameters"  /v RequireSecuritySignature /t REG_DWORD /d 1 /f'

        }
      }
      91805 {
        if (Get-YesNo "$_ - Remove Windows10 UpdateAssistant? " -Results $Results) {
            $Name="UpdateAssistant"
            $Path = "HKLM:\Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\{D5C69738-B486-402E-85AC-2456D98A64E4}"

            #get-wmiobject -class Win32_Product | ?{ $_.Name -like '*Assistant*'} | Format-Table IdentifyingNumber, Name, LocalPackage -AutoSize
            #Write-Host "[ ] Finding GUID for $Name .. Please wait"  -ForegroundColor Gray
            #$GUID = (get-wmiobject -class Win32_Product | ?{ $_.Name -like $Name}).IdentifyingNumber
            $GUID= "{D5C69738-B486-402E-85AC-2456D98A64E4}"
            Write-Host "[.] Checking for product: '$GUID' (Microsoft Windows 10 Update Assistant) .." -ForegroundColor Yellow
            $Products = (get-wmiobject Win32_Product | Where-Object { $_.IdentifyingNumber -like $GUID})
            if ($Products) {
              Remove-Software -Products $Products -Results $Results
            } else {
              Write-Host "[!] Guids not found: $Products !!`n" -ForegroundColor Red
            } 
            # Try to delete from registry, if it exists
            Remove-RegistryItem $Path
        }
      }
      { $QIDsUpdateMicrosoftStoreApps -contains $_ } {
        if (Get-YesNo "$_ Update all store apps? " -Results $Results) {
          <#
          $namespaceName = "root\cimv2\mdm\dmmap"
          $className = "MDM_EnterpriseModernAppManagement_AppManagement01"
          $wmiObj = Get-WmiObject -Namespace $namespaceName -Class $className
          $result = $wmiObj.UpdateScanMethod()
          Write-Verbose $result

          Write-Output "[+] Trying to update Apps via WinGet .." 
          $result2 = winget upgrade --all --accept-source-agreements --accept-package-agreements --silent
          Write-Verbose $result2
          
          # Get the list of installed apps
          Write-Host "[+] Getting list of Store apps.." 
          $appList = Get-AppxPackage -AllUsers # | Where-Object {$_.PackageFamilyName -like "Microsoft.WindowsStore*"}
          
          # Loop through each app and update it
          foreach ($app in $appList) {
              Write-Host "Updating $($app.Name)..."
              $appPackageLoc = $app.InstallLocation
              Add-AppxPackage -register "$appPackageLoc\AppxManifest.xml" -DisableDevelopmentMode -ForceApplicationShutdown
          }
          # Show message when all updates are complete
          Write-Host "[!] All app updates are complete.`n"    
          #>
          # Just open the store for now so we can manually update. ugh.
          & explorer  ms-windows-store:
        }
        $QIDsUpdateMicrosoftStoreApps = 1
      }
      
        ####################################################### Installers #######################################
        # Install newest apps via Ninite

      { $QIDsGhostScript -contains $_ } {
        if (Get-YesNo "$_ Install GhostScript 10.01.1 64bit? " -Results $Results) {
          # 32bit link AGPL: https://github.com/ArtifexSoftware/ghostpdl-downloads/releases/download/gs10011/gs10011w32.exe
          Invoke-WebRequest "https://github.com/ArtifexSoftware/ghostpdl-downloads/releases/download/gs10011/gs10011w64.exe" -OutFile "$($tmp)\ghostscript.exe"
          cmd.exe /c "$($tmp)\ghostscript.exe /S"
          #Delete results file, i.e        "C:\Program Files (x86)\GPLGS\gsdll32.dll found#" as lots of times the installer does not clean this up.. may install the new one in a new location etc
          #$FileToDelete=$results.split(' found')[0]
          $path = Split-Path -Path $results
          $sep=" found#"
          $fileName = ((Split-Path -Path $results -Leaf) -split $sep)[0]
          $FileToDelete="$($path)\$($filename)"
          Write-Host "[.] Removing $($FileToDelete) .."
          Remove-Item $FileToDelete -Force
          if (Test-Path $FileToDelete) {
            Write-Output "[x] Could not delete $($FileToDelete), please remove manually!"
          }
        }
      }
      110330 {  
        if (Get-YesNo "$_ - Install Microsoft Office KB4092465? " -Results $Results) {
            Invoke-WebRequest "https://download.microsoft.com/download/3/6/E/36EF356E-85E4-474B-AA62-80389072081C/mso2007-kb4092465-fullfile-x86-glb.exe" -outfile "$($tmp)\kb4092465.exe"
            cmd.exe /c "$($tmp)\kb4092465.exe /quiet /passive /norestart"
        }
      }
      372348 {
        if (Get-YesNo "$_ - Intel Chipset INF util ? " -Results $Results) {
            Invoke-WebRequest "https://downloadmirror.intel.com/774764/SetupChipset.exe" -OutFile "$($tmp)\setupchipset.exe"
            # https://downloadmirror.intel.com/774764/SetupChipset.exe
            cmd /c "$($tmp)\setupchipset.exe -s -accepteula  -norestart -log $($tmp)\intelchipsetinf.log"
            # This doesn't seem to be working, lets just download it and run it for now..
            #cmd /c "$($tmp)\setupchipset.exe -log $($tmp)\intelchipsetinf.log"
            # may be 'Error: this platform is not supported' ..
        }
      }
      372300 {
        if (Get-YesNo "$_ - Intel RST ? " -Results $Results) {
            #Invoke-WebRequest "https://downloadmirror.intel.com/655256/SetupRST.exe" -OutFile "$($tmp)\setuprst.exe"
            Invoke-WebRequest "https://downloadmirror.intel.com/773229/SetupRST.exe" -OutFile "$($tmp)\setuprst.exe"
            
            cmd /c "$($tmp)\setuprst.exe -s -accepteula -norestart -log $($tmp)\intelrstinf.log"
            # OR, extract MSI from this exe and run: 
            # msiexec.exe /q ALLUSERS=2 /m MSIDTJBS /i “RST_x64.msi” REBOOT=ReallySuppress
        }   
      }
      { $QIDsIntelGraphicsDriver  -contains $_ } {
        if (Get-YesNo "$_ Install newest Intel Graphics Driver? " -Results $Results) { 
          Write-Output "[!] THIS WILL NEED TO BE RUN MANUALLY... OPENING BROWSER TO INTEL SUPPORT ASSISTANT PAGE!"
          explorer "https://www.intel.com/content/www/us/en/support/intel-driver-support-assistant.html"
           <#
            #  Intel Graphics driver - https://www.intel.com/content/www/us/en/support/products/80939/graphics.html
            $CPUName = (gwmi win32_processor).Name
            $CPUModel=$CPUName.split('-')[1].split(' ')[0]   # Hope this stays working.. Looks good here.
            $CPUGeneration = $CPUModel[0]
            Write-Output "[.] Found CPU: $CPUName"
            if ($CPUName -like "*i3*") { 
              # Use this to pick the correct driver from the Intel page..
              # Looks like they all point to the same driver so I guess this isn't needed.. Lets still check at least that the computer has an intel i* proc
              wget "https://downloadmirror.intel.com/30196/a08/win64_15.40.5171.exe" -OutFile "$($tmp)\intelgraphics.exe"  
            } else {
              if ($CPUName -like "*i5*") { 
                 wget "https://downloadmirror.intel.com/30196/a08/win64_15.40.5171.exe" -OutFile "$($tmp)\intelgraphics.exe"
                 $rest=$CPUName.split('i5-')[1]
              } else {
                if ($CPUName -like "*i7*") { 
                   wget "https://downloadmirror.intel.com/30196/a08/win64_15.40.5171.exe" -OutFile "$($tmp)\intelgraphics.exe"
                   $rest=$CPUName.split('i7-')[1]
                } else {
                  if ($CPUName -like "*i9*") { 
                    wget "https://downloadmirror.intel.com/30196/a08/win64_15.40.5171.exe" -OutFile "$($tmp)\intelgraphics.exe"
                    $rest=$CPUName.split('i9-')[1]
                  } else {
                    Write-Output "[X] Error: No Intel CPU found!" 
                  }
                }
              }
            }
            cmd /c "$($tmp)\intelgraphics.exe"
            #>
            $QIDsIntelGraphicsDriver = 1 # All done, remove variable to prevent this from running twice
        } else { $QIDsIntelGraphicsDriver=1 }
      }
      
      { $QIDsAppleiCloud -contains $_ } {
        <#
        if (Get-YesNo "$_ Install newest Apple iCloud? ") { 
            Invoke-WebRequest "" -OutFile "$($tmp)\icloud.exe"
            cmd /c "$($tmp)\icloud.exe"
            $QIDsAppleiCloud = 1 # All done, remove variable to prevent this from running twice
        } else { $QIDsAppleiCloud = 1 } # Do not ask again
        #>
        # https://silentinstallhq.com/apple-icloud-install-and-uninstall-powershell/  # THIS SHOULD BE USEFUL.....
        "$_ Can't deploy Apple iCloud via script yet!!! Please install manually! Opening Browser to iCloud page: "
        explorer "https://apps.microsoft.com/store/detail/icloud/9PKTQ5699M62?hl=en-us&gl=us"
      }
      { $QIDsAppleiTunes -contains $_ } {
        if (Get-YesNo "$_ Install newest Apple iTunes? " -Results $Results) { 
            Invoke-WebRequest "https://ninite.com/itunes/ninite.exe" -OutFile "$($tmp)\itunes.exe"
            cmd /c "$($tmp)\itunes.exe"
            $QIDsAppleiTunes = 1 # All done, remove variable to prevent this from running twice
        } else { $QIDsAppleiTunes = 1 } # Do not ask again
      }
      { $QIDsChrome -contains $_ } {
        if (Get-YesNo "$_ Install newest Google Chrome? " -Results $Results) { 
            #  Google Chrome - https://ninite.com/chrome/ninite.exe
            Invoke-WebRequest "https://ninite.com/chrome/ninite.exe" -OutFile "$($tmp)\ninite.exe"
            cmd /c "$($tmp)\ninite.exe"
            $QIDsChrome = 1 # All done, remove variable to prevent this from running twice
        } else { $QIDsChrome = 1 }
      }
      { $QIDsFirefox -contains $_ } {
        if (Get-YesNo "$_ Install newest Firefox? " -Results $Results) { 
            #  Firefox - https://ninite.com/firefox/ninite.exe
            Invoke-WebRequest "https://ninite.com/firefox/ninite.exe" -OutFile "$($tmp)\ninite.exe"
            cmd /c "$($tmp)\ninite.exe"
            $ResultsFolder = Parse-ResultsFolder $Results
            if ($ResultsFolder -like "*AppData*") {
              Delete-Folder $ResultsFolder
            }          
            $QIDsFirefox = 1
        } else { $QIDsFirefox = 1 }
      }
      { $QIDsZoom -contains $_ } {
        if (Get-YesNo "$_ Install newest Zoom Client? " -Results $Results) { 
            #  Zoom client - https://ninite.com/zoom/ninite.exe
            Invoke-WebRequest "https://ninite.com/zoom/ninite.exe" -OutFile "$($tmp)\ninite.exe"
            cmd /c "$($tmp)\ninite.exe"
            #If Zoom folder is in another users AppData\Local folder, this will not work
            $FolderFound = $false
            foreach ($Result in $Results) {
              if ($Result -like "*AppData*") {
                $FolderFound = $true
              }
            }
            if ($FolderFound) { Delete-Folder (Parse-ResultsFolder -Results $Results) }
            $QIDsZoom = 1
        } else { $QIDsZoom = 1 }
      }
      { $QIDsTeamViewer -contains $_ } {
        if (Get-YesNo "$_ Install newest Teamviewer? " -Results $Results) { 
            #  Teamviewer - https://ninite.com/teamviewer15/ninite.exe
            Invoke-WebRequest "https://ninite.com/teamviewer15/ninite.exe" -OutFile "$($tmp)\ninite.exe"
            cmd /c "$($tmp)\ninite.exe"
            $QIDsTeamViewer = 1
        } else { $QIDsTeamViewer = 1 }
      }
      { $QIDsDropbox -contains $_ } {
        if (Get-YesNo "$_ Install newest Dropbox? " -Results $Results) { 
            #  Dropbox - https://ninite.com/dropbox/ninite.exe
            Invoke-WebRequest "https://ninite.com/dropbox/ninite.exe" -OutFile "$($tmp)\ninite.exe"
            cmd /c "$($tmp)\ninite.exe"
            $QIDsDropbox = 1
        } else { $QIDsDropbox = 1 }
      }
  
        ############################
        # Others: (non-ninite)
  
      { $QIDsOracleJava -contains $_ } {
        if (Get-YesNo "$_ Check Oracle Java for updates? " -Results $Results) { 
            #  Oracle Java 17 - https://download.oracle.com/java/17/latest/jdk-17_windows-x64_bin.msi
            #wget "https://download.oracle.com/java/18/latest/jdk-18_windows-x64_bin.msi" -OutFile "$($tmp)\java17.msi"
            #msiexec /i "$($tmp)\java18.msi" /qn /quiet /norestart
            . "c:\Program Files (x86)\Common Files\Java\Java Update\jucheck.exe"
            $QIDsOracleJava = 1
        } else { $QIDsOracleJava = 1 }
      }
      { $QIDsAdoptOpenJDK -contains $_ } {
        if (Get-YesNo "$_ Install newest Adopt Java JDK? " -Results $Results) { 
            Invoke-WebRequest "https://ninite.com/adoptjavax8/ninite.exe" -OutFile "$($tmp)\ninitejava8x64.exe"
            cmd /c "$($tmp)\ninitejava8x64.exe"
            $QIDsAdoptOpenJDK = 1
        } else { $QIDsAdoptOpenJDK = 1 }
      }
      { $QIDsVirtualBox -contains $_ } {
        if (Get-YesNo "$_ Install newest VirtualBox 6.1.36? " -Results $Results) { 
            Invoke-WebRequest "https://download.virtualbox.org/virtualbox/6.1.36/VirtualBox-6.1.36-152435-Win.exe" -OutFile "$($tmp)\virtualbox.exe"
            cmd /c "$($tmp)\virtualbox.exe"
            $QIDsVirtualBox = 1
        } else { $QIDsVirtualBox = 1 } 
      }
      { $QIDsDellCommandUpdate -contains $_ } {
        if (Get-YesNo "$_ Install newest Dell Command Update? " -Results $Results) { 
            #wget "https://dl.dell.com/FOLDER08334704M/2/Dell-Command-Update-Windows-Universal-Application_601KT_WIN_4.5.0_A00_01.EXE" -OutFile "$($tmp)\dellcommand.exe"
            $DCUExe = (GCI "\\server\data\secaud\" | Where {$_.Name -like "Dell-Command-Update-*"}).FullName
            cmd /c "$($DCUExe) /s"
            $QIDsDellCommandUpdate  = 1
        } else { $QIDsDellCommandUpdate  = 1 }
      }
      { 105734 -eq $_ } {
        if (Get-YesNo "$_ Remove older versions of Adobe Reader ? " -Results $Results) { 
          $Products = (get-wmiobject Win32_Product | Where-Object { $_.Name -like 'Adobe Reader*'})
          if ($Products) {
            Remove-Software -Products $Products -Results $Results
          } else {
            Write-Host "[!] Adobe products not found under 'Adobe Reader*' $Products !!`n" -ForegroundColor Red
          }  
        }
      }
      { $QIDsAdobeReader -contains $_ } {
        if (Get-YesNo "$_ Install newest Adobe Reader DC ? ") {
          Download-NewestAdobeReader
          #cmd /c "$($tmp)\readerdc.exe"
          $Outfile = "$($tmp)\readerdc.exe"
          # silent install
          Start-Process -FilePath $Outfile -ArgumentList "/sAll /rs /rps /msi /norestart /quiet EULA_ACCEPT=YES" -WorkingDirectory $env:TEMP -Wait -LoadUserProfile

          $QIDsAdobeReader = 1
        } else { $QIDsAdobeReader = 1 }
      }
      { $QIDsMicrosoftSilverlight -contains $_ } {
        if (Get-YesNo "$_ Remove Microsoft Silverlight ? ") {
          Write-Host "[.] Checking for product: '{89F4137D-6C26-4A84-BDB8-2E5A4BB71E00}' (Microsoft Silverlight) .." -ForegroundColor Yellow
          $Products = (get-wmiobject Win32_Product | Where-Object { $_.IdentifyingNumber -like '{89F4137D-6C26-4A84-BDB8-2E5A4BB71E00}'})
          if ($Products) {
              Remove-Software -Products $Products -Results $Results
              $QIDsMicrosoftSilverlight = 1
          } else {
            Write-Host "[!] Guids not found: $Products !!`n" -ForegroundColor Red
            $QIDsMicrosoftSilverlight = 1
          } 
        }
      }
      { $QIDsSQLServerCompact4 -contains $_ } {
        if (Get-YesNo "$_ Remove MS SQL Server Compact 4 ? ") {
          Write-Host "[.] Checking for product: '{78909610-D229-459C-A936-25D92283D3FD}' (SQL Server Compact 4) .." -ForegroundColor Yellow
          $Products = (get-wmiobject Win32_Product | Where-Object { $_.IdentifyingNumber -like '{78909610-D229-459C-A936-25D92283D3FD}'})
          if ($Products) {
              Remove-Software -Products $Products -Results $Results
              $QIDsSQLServerCompact4 = 1
          } else {
            Write-Host "[!] Guids not found: $Products !!`n" -ForegroundColor Red
            $QIDsSQLServerCompact4  = 1
          } 
        }
      }
      { $QIDsMicrosoftAccessDBEngine -contains $_ } {
        if (Get-YesNo "$_ Remove MicrosoftAccessDBEngine ? ") {
          Write-Host "[.] Checking for product: '{9012.. or {90140000-00D1-0409-0000-0000000FF1CE}' (MicrosoftAccessDBEngine) .." -ForegroundColor Yellow
          $Products = (get-wmiobject Win32_Product | Where-Object { $_.IdentifyingNumber -like '{90120000-00D1-0409-0000-0000000FF1CE}' -or `
                                                            $_.IdentifyingNumber -like '{90140000-00D1-0409-1000-0000000FF1CE}'})
          if ($Products) {
              Remove-Software -Products $Products -Results $Results
              $QIDsMicrosoftAccessDBEngine = 1
          } else {
            Write-Host "[!] Guids not found: $Products !!`n" -ForegroundColor Red
            $QIDsMicrosoftAccessDBEngine = 1
          }
        }
      }
      { $QIDsMicrosoftVisualStudioActiveTemplate -contains $_ } {
        $notfound = $true
        if (Get-YesNo "$_ $_ Install Microsoft Visual C++ 2005/8 Service Pack 1 Redistributable Package MFC Security Update? " -Results $Results) { 
          $Installed=get-wmiobject -class Win32_Product | Where-Object{ $_.Name -like '*Microsoft Visual*'} # | Format-Table IdentifyingNumber, Name, LocalPackage -AutoSize
          if ($Installed | Where-Object {$_.IdentifyingNumber -like '{9A25302D-30C0-39D9-BD6F-21E6EC160475}'}) { 
              Write-Host "[!] Found Microsoft Visual C++ 2008 Redistributable - x86 "
              $notfound = $false
              Invoke-WebRequest "https://download.microsoft.com/download/5/D/8/5D8C65CB-C849-4025-8E95-C3966CAFD8AE/vcredist_x86.exe" -OutFile "$($tmp)\vcredist2008x86.exe"
              cmd /c "$($tmp)\vcredist2008x86.exe /q"
              $QIDsMicrosoftVisualStudioActiveTemplate = 1
          }
          if ($Installed | Where-Object { $_.IdentifyingNumber -like '{837b34e3-7c30-493c-8f6a-2b0f04e2912c}'}) {
            Write-Host "[!] Found Microsoft Visual C++ 2005 Redistributable"
            $notfound = $false
            Invoke-WebRequest "https://download.microsoft.com/download/8/B/4/8B42259F-5D70-43F4-AC2E-4B208FD8D66A/vcredist_x86.EXE" -OutFile "$($tmp)\vcredist2005.exe"
            cmd /c "$($tmp)\vcredist2005.exe /q"
            $QIDsMicrosoftVisualStudioActiveTemplate = 1
          }
          if ($Installed | Where-Object { $_.IdentifyingNumber -like '{710f4c1c-cc18-4c49-8cbf-51240c89a1a2}'}) {
            Write-Host "[!] Found Microsoft Visual C++ 2005 Redistributable - x86"
            $notfound = $false
            Invoke-WebRequest "https://download.microsoft.com/download/8/B/4/8B42259F-5D70-43F4-AC2E-4B208FD8D66A/vcredist_x86.EXE" -OutFile "$($tmp)\vcredist2005x86.exe"
            cmd /c "$($tmp)\vcredist2005x86.exe /q"
            $QIDsMicrosoftVisualStudioActiveTemplate = 1
          }
          if ($Installed | Where-Object { $_.IdentifyingNumber -like '{6E8E85E8-CE4B-4FF5-91F7-04999C9FAE6A}'}) { #x64
            Write-Host "[!] Found Microsoft Visual C++ 2005 Redistributable - x64 "
            $notfound = $false
            Invoke-WebRequest "https://download.microsoft.com/download/8/B/4/8B42259F-5D70-43F4-AC2E-4B208FD8D66A/vcredist_x64.EXE" -OutFile "$($tmp)\vcredist2005x64.exe"
            cmd /c "$($tmp)\vcredist2005x64.exe /q"
            $QIDsMicrosoftVisualStudioActiveTemplate = 1
          } 

            <# PATCHED versions:
            IdentifyingNumber                      Name                                                           LocalPackage
            -----------------                      ----                                                           ------------
            {ad8a2fa1-06e7-4b0d-927d-6e54b3d31028} Microsoft Visual C++ 2005 Redistributable (x64)                C:\Windows\Installer\4cd95b2e.msi
            {5FCE6D76-F5DC-37AB-B2B8-22AB8CEDB1D4} Microsoft Visual C++ 2008 Redistributable - x64 9.0.30729.6161 c:\Windows\Installer\4cd95b3a.msi
            {9BE518E6-ECC6-35A9-88E4-87755C07200F} Microsoft Visual C++ 2008 Redistributable - x86 9.0.30729.6161 c:\Windows\Installer\4cd95b36.msi
            {710f4c1c-cc18-4c49-8cbf-51240c89a1a2} Microsoft Visual C++ 2005 Redistributable                      C:\Windows\Installer\4cd95b32.msi
            #>
          if ($notfound) {
            Write-Host "[!] Guids not found among: " -ForegroundColor Red
            $Installed
            Write-Host "`n"
            $QIDsMicrosoftVisualStudioActiveTemplate = 1
          }  
        }
      }


      { $QIDsMicrosoftNETCoreV5 -contains $_ } {
            <# Remove one or all of these??
            IdentifyingNumber                      Name                                           LocalPackage
            -----------------                      ----                                           ------------
            {8BA25391-0BE6-443A-8EBF-86A29BAFC479} Microsoft .NET Host FX Resolver - 5.0.17 (x64) C:\Windows\Installer\a3227a.msi
            {5A66E598-37BD-4C8A-A7CB-A71C32ABCD78} Microsoft .NET Runtime - 5.0.17 (x64)          C:\Windows\Installer\a32276.msi
            {E663ED1E-899C-40E8-91D0-8D37B95E3C69} Microsoft .NET Host - 5.0.17 (x64)             C:\Windows\Installer\a3227f.msi


            For now, will remove just the Runtime which I believe is the only vulnerability..  Maybe we remove all 3 though, will find out.
            #>
            Write-Host "[.] Checking for product: '{5A66E598-37BD-4C8A-A7CB-A71C32ABCD78}' (.NET Core 5) .." -ForegroundColor Yellow
            $Products = (get-wmiobject Win32_Product | Where-Object { $_.IdentifyingNumber -like '{5A66E598-37BD-4C8A-A7CB-A71C32ABCD78}'})
            if ($Products) {
                Remove-Software -Products $Products -Results $Results
                $QIDsMicrosoftNETCoreV5 = 1
            } else {
              Write-Host "[!] Guids not found: $Products !!`n" -ForegroundColor Red
              $QIDsMicrosoftNETCoreV5 = 1
            }             
      }
      91304 {  # Microsoft Security Update for SQL Server (MS16-136)
        $inst = (get-itemproperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server' -ErrorAction SilentlyContinue).InstalledInstances
        foreach ($i in $inst)
        {
          $p = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL').$i
          $SQLVersion = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").Version
          $SQLEdition = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$p\Setup").Edition
        }  # Version lists: https://sqlserverbuilds.blogspot.com/
        <#
        SQL Server 2016	13.0.1601.5				
        Support end date: 2021-07-13	+ CU9				
        Ext. end date: 2026-07-14					
        
        SQL Server 2014	12.0.2000.8				
        Support end date: 2019-07-09	+ CU14				
        Ext. end date: 2024-07-09					
        
        Obsolete versions – out of support					
        SQL Server 2012	11.0.2100.60				
        codename Denali	+ CU11				
        Support end date: 2017-07-11					
        Ext. end date: 2022-07-12					
        
        SQL Server 2008 R2	10.50.1600.1				
        SQL Server 10.5					
        codename Kilimanjaro					
        Support end date: 2014-07-08					
        Ext. end date: 2019-07-09					
        
        SQL Server 2008	10.0.1600.22				
        SQL Server 10					
        codename Katmai					
        Support end date: 2014-07-08					
        Ext. end date: 2019-07-09					
#>
        if (Get-YesNo "$_ Install SQL Server $SQLVersion $SQLEdition update? " -Results $Results) { 
          if ("$SQLVersion $SQLEdition" -eq "12.2.5000.0 Express Edition") { # SQL Server 2014 Express
            Invoke-WebRequest "https://www.microsoft.com/en-us/download/confirmation.aspx?id=54190&6B49FDFB-8E5B-4B07-BC31-15695C5A2143=1" -OutFile "$($tmp)\sqlupdate.exe"
            cmd /c "$($tmp)\sqlupdate.exe /q"
          }
          if ("$SQLVersion $SQLEdition" -eq "12.2.5000.0 Standard Edition") { # SQL Server 2014
            Invoke-WebRequest "https://www.microsoft.com/en-us/download/confirmation.aspx?id=57474&6B49FDFB-8E5B-4B07-BC31-15695C5A2143=1" -OutFile "$($tmp)\sqlupdate.exe"
            cmd /c "$($tmp)\sqlupdate.exe /q"
          }
        }
      }
      { $QIDsNVIDIA -contains $_ } {
        if (Get-YesNo "$_ Install newest NVidia drivers ? " -Results $Results) { 
            $NvidiacardFound = $false
            Write-Host "[.] Video Cards found:"
            foreach($gpu in Get-WmiObject Win32_VideoController) {  
              Write-Host $gpu.Description
              if ($gpu.Description -like '*NVidia*') {
                $NvidiacardFound = $true
              }
            }
            if ($NvidiacardFound) {
              Start-Browser "https://www.nvidia.com/download/index.aspx"
              Write-Host "[!] Download and install latest NVidia drivers.. Manual fix!"
            } else {
              Write-Host "[!] No NVIDIA Card found, should be save to remove."
              if (Test-Path "c:\windows\system32\nvvsvc.exe") {
                if (Get-YesNo "$_ Remove NVIDIA PrivEsc exe c:\windows\system32\nvvsvc.exe ? ") { 
                  Write-Host "[.] Running: 'taskkill /f /im nvvsvc.exe' .."
                  cmd.exe /c "taskkill /f /im nvvsvc.exe"
                  Write-Host "[.] Running: 'del c:\windows\System32\nvvsvc.exe /f /s /q'  .."
                  cmd.exe /c "del c:\windows\System32\nvvsvc.exe /f /s /q"
                  if (!(Test-Path "c:\windows\system32\nvvsvc.exe")) {
                    Write-Host "[.] Success!"
                  } else {
                    Write-Host "[!] Error deleting %windir%\System32\nvvsvc.exe !! Not fixed."
                  }
                  
                }
              } else {
                Write-Host "[!] Error, can't find C:\Windows\System32\nvvsvc.exe ! Looks like its already been deleted?"
              }
            }
        } else { $QIDsNVIDIA = 1 }
      }
      376609 {
        if (Get-YesNo "$_ Delete nvcpl.dll for NVIDIA GPU Display Driver Multiple Vulnerabilities (May 2022) ? " -Results $Results) { 
          Delete-File "C:\Windows\System32\nvcpl.dll" -Results $Results
        }
      }    
      370468 {
        if (Get-YesNo "$_ Remove Cisco WebEx ? ") {
          Write-Host "[.] Checking for product: 'Cisco WebEx*' " -ForegroundColor Yellow
          $Products = (get-wmiobject Win32_Product | Where-Object { $_.Name -like 'Cisco WebEx*'})
          if ($Products) {
              Remove-Software -Products $Products  -Results $Results
          } else {
            Write-Host "[!] Product not found: 'Cisco WebEx*' !!`n" -ForegroundColor Red
          }    
        }     
      }
      19472 {
        if (Get-YesNo "$_ Install reg key for Microsoft SQL Server sqldmo.dll ActiveX Buffer Overflow Vulnerability - Zero Day (CVE-2007-4814)? " -Results $Results) { 
          # Set: HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Internet Explorer\ActiveX Compatibility\{10020200-E260-11CF-AE68-00AA004A34D5}  Compatibility Flags 0x400
          New-Item -Path "HKLM:\SOFTWARE\Microsoft\Internet Explorer\ActiveX Compatibility" -Name "{10020200-E260-11CF-AE68-00AA004A34D5}"
          New-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Internet Explorer\ActiveX Compatibility\{10020200-E260-11CF-AE68-00AA004A34D5}" -Name "Compatibility Flags" -Value 0x400
        }
      }
	
      100269 {
        if (Get-YesNo "$_ Install reg keys for Microsoft Internet Explorer Cumulative Security Update (MS15-124)? " -Results $Results) { 
          New-Item -Path "HKLM:\SOFTWARE\Microsoft\Internet Explorer\Main\FeatureControl" -Name "FEATURE_ALLOW_USER32_EXCEPTION_HANDLER_HARDENING"
          New-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_ALLOW_USER32_EXCEPTION_HANDLER_HARDENING" -Name "iexplore.exe" -Value 1
          New-Item -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Internet Explorer\Main\FeatureControl" -Name "FEATURE_ALLOW_USER32_EXCEPTION_HANDLER_HARDENING"
          New-ItemProperty -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_ALLOW_USER32_EXCEPTION_HANDLER_HARDENING" -Name "iexplore.exe" -Value 1
        } 
      }
      90954 {
        if (Get-YesNo "$_ Install reg key for 2012 Windows Update For Credentials Protection and Management (Microsoft Security Advisory 2871997) (WDigest plaintext remediation)? " -Results $Results) { 
          New-ItemProperty -Path "HKLM:\System\CurrentControlSet\Control\SecurityProviders\WDigest" -Name "UseLogonCredential" -Value 0
        }
      }
      91621 {
        if (Get-YesNo "$_ Delete Microsoft Defender Elevation of Privilege Vulnerability April 2020? " -Results $Results) { 
          # This will ask twice due to Delete-File, but I want to offer results first. Could technically add -Results to Delete-File..
          Delete-File "C:\WINDOWS\System32\MpSigStub.exe" -Results $Results
        }
      }
      91649 {
        if (Get-YesNo "$_ Delete Microsoft Defender Elevation of Privilege Vulnerability June 2020? " -Results $Results) { 
          Delete-File "$($env:ProgramFiles)\Windows Defender\MpCmdRun.exe" -Results $Results
        }
      }
      91972 {
        if (Get-YesNo "$_ Delete Microsoft Windows Malicious Software Removal Tool Security Update for January 2023? " -Results $Results) { 
          Delete-File "$($env:windir)\system32\MRT.exe" -Results $Results
        }
      }
      105803 {
        if (Get-YesNo "$_ Remove EOL/Obsolete Software: Adobe Shockwave Player 12 ? " -Results $Results) { 
          $Products = (get-wmiobject Win32_Product | Where-Object { $_.Name -like 'Adobe Shockwave*'})
          if ($Products) {
              Remove-Software -Products $Products  -Results $Results
          } else {
            Write-Host "[!] Product not found: 'Adobe Shockwave*' !!`n" -ForegroundColor Red
          }    
        }
      }
      106105 {
        if (Get-YesNo "$_ Remove EOL/Obsolete Software: Microsoft .Net Core Version 3.1 Detected? " -Results $Results) { 
          Delete-Folder "$($env:programfiles)\dotnet\shared\Microsoft.NETCore.App\3.1.32" -Results $Results
        }
      }
      378332 {
        if (Get-YesNo "$_ Fix WinVerifyTrust Signature Validation Vulnerability? " -Results $Results) { 
          Write-Output "[.] Creating registry item: HKLM:\Software\Microsoft\Cryptography\Wintrust\Config\EnableCertPaddingCheck=1"
          New-Item -Path "HKLM:\Software\Microsoft\Cryptography\Wintrust\Config" -Force | Out-Null
          New-ItemProperty -Path "HKLM:\Software\Microsoft\Cryptography\Wintrust\Config" -Name "EnableCertPaddingCheck" -Value "1" -PropertyType "String" -Force | Out-Null
          
          Write-Output "[.] Creating registry item: HKLM:\Software\Wow6432Node\Microsoft\Cryptography\Wintrust\Config\EnableCertPaddingCheck=1"
          New-Item -Path "HKLM:\Software\Wow6432Node\Microsoft\Cryptography\Wintrust\Config" -Force | Out-Null
          New-ItemProperty -Path "HKLM:\Software\Wow6432Node\Microsoft\Cryptography\Wintrust\Config" -Name "EnableCertPaddingCheck" -Value "1" -PropertyType "String" -Force | Out-Null    
          Write-Output "[!] Done!"
        }
      }
      106116 {        
        if (Get-YesNo "$_ Delete EOL/Obsolete Software: Microsoft Visual C++ 2010 Redistributable Package Detected? " -Results $Results) { 
          Delete-File "$($env:ProgramFiles)\Common Files\Microsoft Shared\VC\msdia100.dll" -Results $Results
          Delete-File "$(${env:ProgramFiles(x86)})\Common Files\Microsoft Shared\VC\msdia100.dll" -Results $Results
        }       
      }	
      110432 {
        $ResultsEXE = "C:\Program Files (x86)\Microsoft Office\root\Office16\GRAPH.EXE"
        $ResultsEXEVersion = Check-FileVersion $ResultsEXE
        if ($ResultsEXEVersion -le 16.0.16227.20258) {
          Write-Host "[!] Vulnerable version $ResultsEXE found : $ResultsEXEVersion <= 16.0.16227.20258"

        }
      }
      378131 {
        Write-Host "[?] $_ Microsoft Windows Snipping Tool Information Disclosure Vulnerability" 
        $ResultsEXE = "$env:windir\system32\SnippingTool.exe"
        Write-Host "[.] Checking $ResultsEXE version.."
        $ResultsEXEVersion = Check-FileVersion $ResultsEXE
        if ([version]$ResultsEXEVersion -lt [version]10.2008.3001.0) {
          Write-Host "[!] Vulnerable version $ResultsEXE found : $ResultsEXEVersion < 10.2008.3001.0"  -ForegroundColor Red
          Write-Host "[!] Please update Snipping Tool manually!!!" -ForegroundColor Red
          & explorer "https://apps.microsoft.com/store/detail/snipping-tool/9MZ95KL8MR0L?hl=en-us&gl=us"
        } else {
          Write-Host "[!] Fixed version $ResultsEXE found : $ResultsEXEVersion >= 10.2008.3001.0. Already patched"  -ForegroundColor Green
        }
      }
      372294 {
        if (Get-YesNo "$_ Fix service permissions issues? " -Results $Results) {
          $ServicePermIssues = Get-ServicePermIssues -Results $Results
          Write-Verbose "IN MAIN LOOP: Returned from Get-ServicePermIssues: $ServicePermIssues"
          foreach ($file in $ServicePermIssues) {
            if (!(Check-ServiceFilePerms $file)) {
              Write-Output "[+] Permissions are good for $file "
            } else { # FIX PERMS.
              
              $objACL = Get-ACL $file
              Write-Output "[.] Checking owner of $file .. $($objacl.Owner)"
              # Check for file owner, to resolve problems setting inheritance (if needed)
              if ($objacl.Owner -notlike "*$($env:USERNAME)") { # also allow [*\]User besides just User
                #if (Get-YesNo "Okay to take ownership of $file as $($env:USERNAME) ?") {   
                if ($true) {   # Lets just do this..
                  $objacl.SetOwner([System.Security.Principal.NTAccount] $env:USERNAME)
                } else { 
                  Write-Verbose "[.] WARNING: Likely the changes will fail, we are not the owner."
                }
              }
              try {
                Set-ACL $file -AclObject $objACL  
              } catch {
                Write-Output "[!] ERROR: Couldn't set owner to $($env:Username) on $($file) .."
              }
              $objACL = Get-ACL $file
              Write-Verbose "[.] Checking inheritance for $file - $(!($objacl.AreAccessRulesProtected)).."
              if (!($objACL.AreAccessRulesProtected)) {  # Inheritance is turned on.. Lets turn it off for this one file.
                # Remove inheritance, resulting ACLs will be limited
                Write-Verbose "[.] Turning off inheritance for $file"
                $objacl.SetAccessRuleProtection($true,$true)  # 1=protected?, 2=copy inherited ACE? we will modify below
                #$objacl.SetAccessRuleProtection($true,$false)  # 1=protected?, 2=drop inherited rules
                try {
                  Set-ACL $file -AclObject $objACL  
                } catch {
                  Write-Output "[!] ERROR: Couldn't set inheritance on $($file) .."
                }
              }
              Write-Verbose "[.] Removing Everyone full permissions on $file .."
              $Right = [System.Security.AccessControl.FileSystemRights]::ReadAndExecute
              $InheritanceFlag = [System.Security.AccessControl.InheritanceFlags]::None 
              $PropagationFlag = [System.Security.AccessControl.PropagationFlags]::InheritOnly  
              $objType = [System.Security.AccessControl.AccessControlType]::Allow 
              $objUser = New-Object System.Security.Principal.NTAccount("Everyone") 
              $objACE = New-Object System.Security.AccessControl.FileSystemAccessRule `
                  ($objUser, $Right, $InheritanceFlag, $PropagationFlag, $objType) 
              $objACL = Get-ACL $file
              $objACL.RemoveAccessRuleAll($objACE) 
              try {
                Set-ACL $file -AclObject $objACL  
              } catch {
                Write-Output "[!] ERROR: Couldn't remove Everyone-full permissions on $file .."
              }
              Write-Verbose "[.] Removing Users-Write/Modify/Append permissions on $file .."
              # .. Remove write/append/etc from 'Users'. First remove Users rule completely.
              $objUser = New-Object System.Security.Principal.NTAccount("Users") 
              $objACE = New-Object System.Security.AccessControl.FileSystemAccessRule `
                  ($objUser, $Right, $InheritanceFlag, $PropagationFlag, $objType) 
              $objACL = Get-ACL $file 
              try {
                $objACL.RemoveAccessRuleAll($objACE) 
              } catch {
                Write-Output "[!] ERROR: Couldn't reset Users permissions on $file .."
              }
              # Then add ReadAndExecute only for Users
              $Right = [System.Security.AccessControl.FileSystemRights]::ReadAndExecute
              $objACE = New-Object System.Security.AccessControl.FileSystemAccessRule `
                  ($objUser, $Right, $InheritanceFlag, $PropagationFlag, $objType) 
              $objACL.AddAccessRule($objACE) 
              try {
                Set-ACL $file -AclObject $objACL  
              } catch {
                Write-Output "[!] ERROR: Couldn't modify Users to R+X permissions on $file .."
              }
              # Check that issue is actually fixed
              if (!(Check-ServiceFilePerms $file)) {
                Write-Output "[+] Permissions are good for $file "
              } else {
                Write-Output "[!] WARNING: Permissions NOT fixed on $file .. "
                Check-FilePerms "$($file)"
              }
            }
          }
          <# 
          # Old code to check with accesschk.. couldn't get this quite right..
          Write-Output "[.] Downloading accesschk.exe from live.Sysinternals.com to check that this is fixed.."
          wget "https://live.sysinternals.com/accesschk.exe" -outfile "\\dc-server\data\secaud\accesschk.exe"
          $AccesschkEveryone = (start-process "\\dc-server\data\secaud\accesschk.exe" -ArgumentList "-accepteula -uwcqv ""Everyone"" *" -WorkingDirectory $env:temp -NoNewWindow)
          $AccesschkUsers = (start-process "\\dc-server\data\secaud\accesschk.exe" -ArgumentList "-accepteula -uwcqv ""Users"" *" -WorkingDirectory $env:temp -NoNewWindow)
          $AccesschkAuthUsers = (start-process "\\dc-server\data\secaud\accesschk.exe" -ArgumentList "-accepteula -uwcqv ""Authenticated Users"" *" -WorkingDirectory $env:temp -NoNewWindow)
          foreach ($a in $AccesschkUsers) {
            Write-Output "[+] $a"
          }
          #>
        }
      }
      91848 {
        if (Get-YesNo "$_ Install Store Installer app update to 1.16.13405.0 ? " -Results $Results) { 
          # Requires -RunAsAdministrator
          if ($true) {
            if ([version]'1.16.13405.0' -gt [version](Get-AppxPackage -Name 'Microsoft.DesktopAppInstaller' -ErrorAction SilentlyContinue).Version) {
              $zip = (Join-Path -Path $tmp -ChildPath 'Microsoft.DesktopAppInstaller_1.16.13405.0_8wekyb3d8bbwe.zip')
              $zipFolder = "$($zip -replace '\.zip','')"
              if (-not(Test-Path -Path $zip)) {
                $HT = @{
                  Uri = 'https://download.microsoft.com/download/6/6/8/6680c5b1-3fbe-4b70-8189-90ea08609563/Microsoft.DesktopAppInstaller\_1.16.13405.0\_8wekyb3d8bbwe.zip'
                  UseBasicParsing = $true
                  ErrorAction = 'Stop'
                  OutFile = $zip
                }
                try {
                  Invoke-WebRequest @HT
                } catch {
                  Write-Warning -Message "Failed to download zip because $($_.Exception.Message)"
                }
              }
              if (Test-Path -Path $zip) {
                if ((Get-FileHash -Path $zip).Hash -eq 'e79cea914ba04b953cdeab38489b3190fcc88e566a43696aaefc0eddba1af6ab' ) {
                  try {
                    Expand-Archive -Path $zip -DestinationPath (Split-Path $zipFolder -Parent) -Force -ErrorAction Stop
                  } catch {
                    Write-Warning -Message "Failed to unzip because $($_.Exception.Message)"
                  }
                  if ('Valid' -in (Get-ChildItem -Path "$($zipFolder)\*" -Include * -Recurse -Exclude '*.xml' | Get-AuthenticodeSignature | Select-Object -ExpandProperty Status | Sort-Object -Unique)) {
                    $HT = @{
                      Online = $true
                      PackagePath = Join-Path -Path $zipFolder -ChildPath 'Microsoft.DesktopAppInstaller_1.16.13405.0_8wekyb3d8bbwe.msixbundle'
                      SkipLicense = $true
                      ErrorAction = 'Stop'
                    }
                    try {
                      $r = Add-AppxProvisionedPackage @HT
                      if ($r.Online) {
                        Write-Verbose 'Successfully provisionned Microsoft.DesktopAppInstaller' -Verbose
                      }
                    } catch {
                      Write-Warning -Message "Failed to install Appx because $($_.Exception.Message)"
                    }
                  }
                } else {
                  Write-Warning -Message "Downloaded zip file thumbprint (SHA256) doesn't match"
                }
              } else {
                Write-Warning -Message "Zip file $($zip) not found"
              }
            } else {
              Write-Verbose -Message 'Current Microsoft.DesktopAppInstaller appx version is not vulnerable' -Verbose
            }
          }
        }
      }
      Default {
        Write-Host "[X] Skipping QID $_ - $ThisTitle" -ForegroundColor Red
      }
    }
}

Write-Host "[o] Done! Stopping transcript" -ForegroundColor Green
Set-Location $oldpwd
# Disabling the file deletion step for now, EPDR keeps killing the script for being 'suspicious' at this point.
#Write-Host "[.] Deleting all temporary files from $tmp .."
#Remove-Item -Path "$tmp" -Recurse -Force -ErrorAction SilentlyContinue
Stop-Transcript
if (!($Automated)) {
  $null = Read-Host "--- Press enter to exit ---"
}
Write-Host "`n"
Exit
